<?php
session_start();

// 🔒 Evitar caché
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// 🔑 Verificar sesión
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}

// 🕒 Tiempo máximo de inactividad (ejemplo: 5 minutos)
$inactividad = 300; // 300 segundos = 5 min

if (!isset($_SESSION['tiempo'])) {
    $_SESSION['tiempo'] = time();
} elseif (time() - $_SESSION['tiempo'] > $inactividad) {
    // Se excedió el tiempo → cerrar sesión
    session_unset();
    session_destroy();
    setcookie(session_name(), '', time() - 3600, '/');
    header("Location: index.php?timeout=1");
    exit();
}

// Actualizar tiempo de última actividad
$_SESSION['tiempo'] = time();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión Disciplinaria | I.E. Santa Teresa</title>
    <link rel="icon" href="img/logosantaie.gif" type="image/x-icon">
    <link rel="stylesheet" href="estilos.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        /* Sobrescribir la paleta de colores para usar la misma de tarde.html */
        :root {
            /* Paleta vibrante de tarde.html */
            --primary-color: #2699C7;
            --secondary-color: #007bff;
            --accent-color: #00d4ff;
            --accent-secondary: #4A90E2;
            
            /* Gradientes actualizados */
            --gradient-bg: linear-gradient(45deg, #2C5AA0 0%, #4A90E2 50%, #00d4ff 100%);
            --gradient-button: linear-gradient(135deg, #2699C7 0%, #007bff 100%);
            --gradient-button-hover: linear-gradient(135deg, #007bff 0%, #00d4ff 100%);
            --table-gradient: linear-gradient(to bottom, #2C5AA0, #4A90E2, rgba(255,255,255,0.9));
            
            /* Efectos y sombras actualizados */
            --shadow-light: 0 2px 10px rgba(38, 153, 199, 0.1);
            --shadow-medium: 0 5px 25px rgba(38, 153, 199, 0.15);
            --shadow-heavy: 0 10px 40px rgba(38, 153, 199, 0.2);
            --shadow-accent: 0 8px 25px rgba(0, 212, 255, 0.3);
        }

        /* Actualizar el overlay del slider para usar la nueva paleta */
        .slide-overlay {
            background: linear-gradient(
                45deg,
                rgba(44, 90, 160, 0.7) 0%,
                rgba(74, 144, 226, 0.5) 50%,  
                rgba(0, 212, 255, 0.3) 100%
            );
        }

        /* Navbar con la nueva paleta */
        .navbar-modern {
            background: rgba(255, 255, 255, 0.95);
            border-bottom: 1px solid rgba(38, 153, 199, 0.1);
        }

        /* Logo con efecto hover actualizado */
        .nav-brand .logo:hover {
            box-shadow: 0 6px 20px rgba(0, 212, 255, 0.3);
        }

        /* Dropdown button con nueva paleta */
        .dropdown-btn {
            background: linear-gradient(135deg, #2699C7 0%, #007bff 100%);
            box-shadow: 0 8px 25px rgba(0, 212, 255, 0.3);
        }

        .dropdown-btn:hover {
            background: linear-gradient(135deg, #007bff 0%, #00d4ff 100%);
            box-shadow: 0 15px 35px rgba(0, 212, 255, 0.4);
        }

        /* Dropdown items con hover actualizado */
        .dropdown-item:hover {
            background: rgba(0, 212, 255, 0.1);
            color: #00d4ff;
        }

        .dropdown-item i {
            color: #2699C7;
        }

        /* Botones primarios actualizados */
        .btn-primary {
            background: linear-gradient(135deg, #2699C7 0%, #007bff 100%);
            box-shadow: 0 8px 25px rgba(0, 212, 255, 0.3);
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, #007bff 0%, #00d4ff 100%);
            box-shadow: 0 15px 35px rgba(0, 212, 255, 0.4);
        }

        /* Indicadores del slider actualizados */
        .indicator.active {
            background: #00d4ff;
            border-color: #00d4ff;
            box-shadow: 0 0 10px rgba(0, 212, 255, 0.5);
        }

        /* Colores de texto actualizados */
        .brand-text {
            color: #2699C7;
        }

        .card-content h2 {
            color: #2699C7;
        }

        .feature-item {
            background: rgba(0, 212, 255, 0.05);
            border: 1px solid rgba(0, 212, 255, 0.1);
        }

        .feature-item:hover {
            background: rgba(0, 212, 255, 0.1);
        }

        .feature-item i {
            color: #00d4ff;
        }

        /* Footer con el mismo color de tarde.html */
        .modern-footer {
            background: rgba(52, 58, 64, 0.95);
            backdrop-filter: blur(15px);
        }

        .footer-logo {
            box-shadow: 0 4px 15px rgba(0, 212, 255, 0.3);
        }

        .footer-link:hover {
            color: #00d4ff;
        }

        /* Efectos de focus actualizados */
        button:focus,
        a:focus {
            outline: 2px solid #00d4ff;
        }

        .dropdown-btn:focus,
        .btn-primary:focus,
        .btn-secondary:focus {
            box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.3);
        }

        /* Mobile toggle con nueva paleta */
        .mobile-toggle span {
            background: #2699C7;
        }

        /* Card icon actualizado */
        .card-icon {
            background: linear-gradient(45deg, #2C5AA0 0%, #4A90E2 50%, #00d4ff 100%);
            box-shadow: 0 8px 25px rgba(0, 212, 255, 0.3);
        }
    </style>
</head>
<body>
    <!-- Navegación Principal -->
    <nav class="navbar-modern">
        <div class="nav-container">
            <div class="nav-brand">
                <img src="img/logosantaie.gif" class="logo" alt="Logo I.E. Santa Teresa">
                <span class="brand-text">I.E. Santa Teresa</span>
            </div>
            
            <!-- Botón desplegable -->
            <div class="dropdown-container">
                <button class="dropdown-btn" id="dropdownBtn">
                    <i class="fas fa-cog"></i>
                    <span>Gestión</span>
                    <i class="fas fa-chevron-down arrow"></i>
                </button>
                <div class="dropdown-menu" id="dropdownMenu">
                    <a href="tabla.php" class="dropdown-item">
                        <i class="fas fa-exclamation-triangle"></i>
                        <span>Amonestaciones</span>
                    </a>
                    <a href="tarde.php" class="dropdown-item">
                        <i class="fas fa-clock"></i>
                        <span>Llegadas Tarde</span>
                    </a>
                </div>
            </div>

            <!-- Menú móvil toggle -->
            <div class="mobile-toggle" id="mobileToggle">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Slider de imágenes -->
    <section class="hero-slider">
        <div class="slider-container">
            <div class="slide active">
                <img src="img/s1.jpeg" alt="Instalaciones educativas">
                <div class="slide-overlay"></div>
            </div>
            <div class="slide">
                <img src="img/s2.jpeg" alt="Estudiantes en actividades">
                <div class="slide-overlay"></div>
            </div>
            <div class="slide">
                <img src="img/s3.jpeg" alt="Aulas modernas">
                <div class="slide-overlay"></div>
            </div>
            <div class="slide">
                <img src="img/s4.jpeg" alt="Espacios deportivos">
                <div class="slide-overlay"></div>
            </div>
            <div class="slide">
                <img src="img/fondo.jpeg" alt="Campus institucional">
                <div class="slide-overlay"></div>
            </div>
        </div>
        
        <!-- Contenido superpuesto al slider -->
        <div class="hero-content">
            <div class="hero-text">
                <h1 class="hero-title">Sistema de Gestión Disciplinaria</h1>
                <p class="hero-subtitle">Control integral y profesional para el seguimiento estudiantil</p>
                </div>
            </div>
        </div>

        <!-- Indicadores del slider -->
        <div class="slider-indicators">
            <button class="indicator active" data-slide="0"></button>
            <button class="indicator" data-slide="1"></button>
            <button class="indicator" data-slide="2"></button>
            <button class="indicator" data-slide="3"></button>
            <button class="indicator" data-slide="4"></button>
        </div>
    </section>

    <!-- Sección de información -->
    <section class="info-section">
        <div class="container">
            <div class="info-card">
                <div class="card-icon">
                    <img src="img/logosantaie.gif" width="100px">
                </div>
                <div class="card-content">
                    <h2>Gestión Disciplinaria Profesional</h2>
                    <p>
                        Nuestra plataforma digital permite llevar un control detallado y sistemático 
                        de las amonestaciones y llegadas tarde de los estudiantes, facilitando 
                        la toma de decisiones pedagógicas y el seguimiento del comportamiento estudiantil.
                    </p>
                    <div class="features-grid">
                        <div class="feature-item">
                            <i class="fas fa-chart-line"></i>
                            <span>Reportes detallados</span>
                        </div>
                        <div class="feature-item">
                            <i class="fas fa-users"></i>
                            <span>Seguimiento individual</span>
                        </div>
                        <div class="feature-item">
                            <i class="fas fa-calendar-alt"></i>
                            <span>Historial completo</span>
                        </div>
                        <div class="feature-item">
                            <i class="fas fa-mobile-alt"></i>
                            <span>Acceso móvil</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="modern-footer">
        <div class="footer-content">
            <div class="footer-brand">
                <img src="img/logosantaie.gif" alt="Logo" class="footer-logo">
                <div class="footer-info">
                    <h3>Institución Educativa Santa Teresa</h3>
                    <p>Sistema de Gestión Disciplinaria</p>
                </div>
            </div>
            <div class="footer-links">
                <a href="https://santateresaie.edu.co/wp-content/uploads/2025/04/POLITICA-DE-PROTECCION-DE-DATOS.pdf" class="footer-link">
                    <i class="fas fa-shield-alt"></i>
                    Política de Privacidad
                </a>
                <a href="#" class="footer-link">
                    <i class="fas fa-envelope"></i>
                    Contacto
                </a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2025 Institución Educativa Santa Teresa. Todos los derechos reservados.</p>
        </div>
    </footer>

    <script>
        // Funcionalidad del dropdown
        const dropdownBtn = document.getElementById('dropdownBtn');
        const dropdownMenu = document.getElementById('dropdownMenu');
        const arrow = dropdownBtn.querySelector('.arrow');

        dropdownBtn.addEventListener('click', () => {
            dropdownMenu.classList.toggle('show');
            arrow.classList.toggle('rotate');
        });

        // Cerrar dropdown al hacer click fuera
        document.addEventListener('click', (e) => {
            if (!dropdownBtn.contains(e.target)) {
                dropdownMenu.classList.remove('show');
                arrow.classList.remove('rotate');
            }
        });

        // Funcionalidad del menú móvil
        const mobileToggle = document.getElementById('mobileToggle');
        const navContainer = document.querySelector('.nav-container');

        mobileToggle.addEventListener('click', () => {
            mobileToggle.classList.toggle('active');
            navContainer.classList.toggle('mobile-open');
        });

        // Funcionalidad del slider
        const slides = document.querySelectorAll('.slide');
        const indicators = document.querySelectorAll('.indicator');
        let currentSlide = 0;

        function showSlide(index) {
            slides.forEach(slide => slide.classList.remove('active'));
            indicators.forEach(indicator => indicator.classList.remove('active'));
            
            slides[index].classList.add('active');
            indicators[index].classList.add('active');
        }

        function nextSlide() {
            currentSlide = (currentSlide + 1) % slides.length;
            showSlide(currentSlide);
        }

        // Auto-slide cada 5 segundos
        setInterval(nextSlide, 5000);

        // Control manual con indicadores
        indicators.forEach((indicator, index) => {
            indicator.addEventListener('click', () => {
                currentSlide = index;
                showSlide(currentSlide);
            });
        });

        // Animaciones al scroll
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -100px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, observerOptions);

        document.querySelectorAll('.info-card, .feature-item').forEach(el => {
            observer.observe(el);
        });
    </script>

     <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
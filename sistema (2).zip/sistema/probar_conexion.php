<?php // Indica que el archivo contiene código PHP y que se empieza a interpretar desde aquí
include 'conexion.php'; // Incluye el archivo 'conexion.php'. Esto significa que antes de ejecutar este script, 
// se cargará y ejecutará todo el código del archivo 'conexion.php'.  
// Normalmente, este archivo contiene las instrucciones para conectarse a una base de datos.
echo "Conexión exitosa a la base de datos.";// Muestra en la pantalla este mensaje de texto si el código llega hasta aquí. 
// Esto usualmente se usa para confirmar que la conexión a la base de datos 
// (definida en 'conexion.php') se ha realizado correctamente.
?> 


<?php
include 'conexion.php';

var_dump($_POST);
exit;


//Verifica que llegaron los datos
if (isset($_POST['id']) && isset($_POST['fecha'])) {
    $id = (int)$_POST['id'];
    $fecha = $conn->real_escape_string($_POST['fecha']); // 'YYYY-MM-DD' esperado

//Insertar en llegadas
    $sql = "UPDATE asistencias SET fecha = '$fecha' WHERE id = $id LIMIT 1";

    if ($conn->query($sql) === TRUE) {
        echo "OK";
    } else {
        http_response_code(500);
        echo "Error: " . $conn->error;
    }
} else {
    http_response_code(400);
    echo "Faltan datos (id o fecha)";
}

$conn->close();
?>

-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-09-2025 a las 01:31:52
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistema_disciplinario`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asistencias`
--

CREATE TABLE `asistencias` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `grupo` varchar(10) NOT NULL,
  `enero` text DEFAULT NULL,
  `febrero` text DEFAULT NULL,
  `marzo` text DEFAULT NULL,
  `abril` text DEFAULT NULL,
  `mayo` text DEFAULT NULL,
  `junio` text DEFAULT NULL,
  `julio` text DEFAULT NULL,
  `agosto` text DEFAULT NULL,
  `septiembre` text DEFAULT NULL,
  `octubre` text DEFAULT NULL,
  `noviembre` text DEFAULT NULL,
  `tabla_id` int(11) DEFAULT 1,
  `tabla_titulo` varchar(255) DEFAULT 'Registro Disciplinario',
  `firma_estudiante` longtext DEFAULT NULL,
  `firma_docente` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `asistencias`
--

INSERT INTO `asistencias` (`id`, `nombre`, `grupo`, `enero`, `febrero`, `marzo`, `abril`, `mayo`, `junio`, `julio`, `agosto`, `septiembre`, `octubre`, `noviembre`, `tabla_id`, `tabla_titulo`, `firma_estudiante`, `firma_docente`, `created_at`, `updated_at`) VALUES
(6, 'Mateo Herrera Díaz', '0-1', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(7, 'Isabella Ríos Torres', '0-2', 'X,X,X,X,X,X', 'X', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:54:01'),
(8, 'Samuel Gómez Ramírez', '0-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(9, 'Sofía Martínez Ruiz', '1-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(10, 'Lucas Fernández Pérez', '1-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(11, 'Emma Vargas Sánchez', '1-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(12, 'Diego Castro Morales', '2-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(13, 'Valentina Romero López', '2-2', 'X', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(14, 'Martín Ortega Ríos', '2-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(15, 'Camila Jiménez Herrera', '3-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(16, 'Tomás Soto Torres', '3-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(17, 'Sara Muñoz Díaz', '3-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(18, 'Benjamín Delgado León', '4-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(19, 'Julieta Silva Ramos', '4-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(20, 'Emilio Vargas Mendoza', '4-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(21, 'Mía Torres Acosta', '5-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(22, 'Joaquín Rivas Romero', '5-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(23, 'Antonella Martínez Gómez', '5-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(24, 'Gael Ruiz Peña', '6-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(25, 'Renata Castro Jiménez', '6-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(26, 'Thiago Ramírez Herrera', '6-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(27, 'Catalina Sánchez López', '7-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(28, 'Maximiliano Vega Ríos', '7-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(29, 'Abigail Moreno Díaz', '7-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(30, 'Damián Morales García', '8-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(31, 'Regina Méndez Pérez', '8-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(32, 'Andrés González Vargas', '8-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(33, 'Paulina Herrera Rojas', '9-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(34, 'Facundo Romero Mendoza', '9-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(35, 'Elena Rodríguez Silva', '9-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(36, 'Juan Pablo Cruz Torres', '10-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(37, 'Aitana Gómez Ramírez', '10-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(38, 'Leonardo Ríos Herrera', '10-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(39, 'María López Sánchez', '11-1', 'X,X', 'X', '', 'X,X,X', '', '', 'X', '', 'X,X', 'X', 'X', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(41, 'Valentina Ruiz Gómez', '11-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(42, 'Isabela Rivera Montoya', '0-4', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(43, 'Samuel Castaño Pineda', '6-4', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(44, 'Valeria Gómez Ríos', '0-1', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(45, 'Tomás López García', '0-2', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(46, 'Luciana Mejía Torres', '0-3', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(47, 'Isabela Rivera Montoya', '0-4', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(48, 'Jerónimo Ortiz Ramírez', '1-1', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(49, 'Camila Restrepo Salas', '1-2', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(50, 'Samuel Pérez Londoño', '1-3', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(51, 'Sara Giraldo Vargas', '2-1', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(52, 'Matías Torres Arenas', '2-2', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(53, 'Emilia Salazar León', '2-3', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(54, 'Juan Pablo Cano', '3-1', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(55, 'Antonia Hoyos Jaramillo', '3-2', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(56, 'Felipe Marín Álvarez', '3-3', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(57, 'Julieta Franco Zuluaga', '4-1', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(58, 'Simón Ríos Estrada', '4-2', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(59, 'Renata Pineda López', '4-3', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(60, 'Emiliano Montoya Díaz', '5-1', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(61, 'Mía Herrera Vélez', '5-2', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(62, 'David Castro Gómez', '5-3', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(63, 'Valentina Londoño Mejía', '6-1', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(64, 'Santiago Ramírez Peña', '6-2', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(65, 'Isabel Zapata Correa', '6-3', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(66, 'Samuel Castaño Pineda', '6-4', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(67, 'Nicole Álvarez Rivas', '7-1', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(68, 'Juan Diego Benítez Hoyos', '7-2', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(69, 'Adriana Palacio Marulanda', '7-3', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(70, 'Pedro Salinas Tobón', '8-1', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(71, 'Laura Ramírez Giraldo', '8-2', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(72, 'Andrés Cardona López', '8-3', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(73, 'Mariana Cano Estrada', '9-1', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(74, 'Iván Morales Gutiérrez', '9-2', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(75, 'Danna Herrera Quintero', '9-3', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(76, 'Tomás Suárez Torres', '10-1', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(77, 'Michelle Vargas Roldán', '10-2', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(78, 'Manuel Ocampo Rivas', '10-3', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(79, 'Daniela Lozano Zuluaga', '11-1', '', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(81, 'María López Sánchez', '11-3', 'X,X', 'X', '', 'X,X,X', '', '', 'X', '', 'X,X', 'X', 'X', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(82, 'AGUDELO ZAPATA MARIA SALOME', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(83, 'AGUINAGA BARRIENTOS CHRISTOPHER REY', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(84, 'ALVAREZ CALLE DANNA ISABELLA', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(85, 'BEDOYA COLORADO DANIEL', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(86, 'BEDOYA SANCHEZ ANA SOFIA', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(87, 'BOTERO CARDONA JUAN JOSE', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(88, 'CALLE RIOS JOHAN', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(89, 'CAMPO MESA JUAN JOSE', '11-2', 'X,X,X,X,X,X,X,X,X,X,X', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 20:48:18'),
(90, 'CAÑAS MENESES SIMON', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(91, 'CANO BOLIVAR SOFIA', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(92, 'COLORADO GALLEGO ALEJANDRA', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(93, 'DAVID ZAPATA MIGUEL ANGEL', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(94, 'GIRALDO GIRALDO YISELA ANDREA', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(95, 'GUERRA GARCES MIGUEL ANGEL', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(96, 'HERNANDEZ TENORIO SEBASTIAN', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(97, 'LONDOÑO DUQUE ISABELLA', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(98, 'LOPEZ LONDOÑO KEVIN ANDRES', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(99, 'MOSQUERA PANIAGUA KENDRY NICOL', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(100, 'OCHOA ALZATE MARIANGEL', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(101, 'ORTIZ GUERRA EMANUEL', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(102, 'OSPINA CHAVARRIA LUIS MIGUEL', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(103, 'OSPINA VELASQUEZ MARÍA JOSÉ', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(104, 'OSSA DAVID SIMON', '11-2', '', '', '', '', '', '', '', 'X,X,X,X,X,X,X,X,X,X,X', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(105, 'PEREZ GUTIERREZ EMANUEL', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(106, 'QUINTERO CLAVIJO STIVEN', '11-2', 'X,X,X', '', '', '', '', '', '', '', '', '', '', 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(107, 'RAMIREZ PINEDA EMANUEL', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(108, 'SALAZAR CORTES DAVID', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(109, 'SEPULVEDA CALLEJAS MICHELLE', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(110, 'TAMAYO RAMIREZ JUAN JOSE', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13'),
(111, 'USUGA CRUZ ISABELLA', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Registro Disciplinario', NULL, NULL, '2025-09-05 19:43:13', '2025-09-05 19:43:13');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `firmas_digitales`
--

CREATE TABLE `firmas_digitales` (
  `id` int(11) NOT NULL,
  `registro_id` int(11) NOT NULL,
  `tipo_firma` enum('estudiante','docente') NOT NULL,
  `firma_data` longblob NOT NULL,
  `fecha_firma` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `firmas_digitales`
--

INSERT INTO `firmas_digitales` (`id`, `registro_id`, `tipo_firma`, `firma_data`, `fecha_firma`) VALUES
(1, 30, 'estudiante', 0x89504e470d0a1a0a0000000d49484452000001f4000000c808060000001e1913e800001000494441547801ec9d6bac355759c78f227d7b017aa1ad5088b55caa4969f48346c5c60b89b14862bc10c1943692a8c16b82d1a051f1021f102f513f4010438436a8441413153411121534463f080d118a4a89b4e5d696424b5b11787ec3bb769f77bf67efb367cf65af99f99dacb5d765d67ad6b37e73f9ef993d33e74b8ffc938004242001094860f20414f4c9af422720010948400212383a1a56d0252c01094840021290c0280414f451303b880424200109486058025316f461c9685d0212908004243021020afa845696ae4a400212908004361150d03791b15e0212908004243021020afa845696ae4a400212908004361150d0379119b65eeb129080042420815e0928e8bde2d498042420010948e0300414f4c3701f7654ad4b40021290c0e20828e88b5be54e580212908004e64840419fe35a1d764e5a9780042420810a0928e815ae145d92800424200109b425a0a0b72566fb6109685d0212908004f622a0a0ef85cd4e12908004242081ba0828e875ad0fbd199680d625200109cc9680823edb55ebc4242001094860490414f425ad6de73a2c01ad4b40021238200105fd80f01d5a021290800424d0170105bd2f92da91c0b004b42e010948602b01057d2b1e174a400212908004a64140419fc67ad24b090c4b40eb1290c0e40928e8935f854e400212908004247074a4a0bb154840024313d0be0424300201057d04c80e21010948400212189a80823e3461ed4b4002c312d0ba0424d01050d01b0c7e48400212908004a64d40419ff6fad37b09486058025a97c0640828e89359553a2a010948400212d84c4041dfccc625129080048625a07509f4484041ef11a6a6242001094840028722a0a01f8abce34a400212189680d6174640415fd80a77ba1290800424304f020afa3cd7abb392800424302c01ad57474041af6e95e890042420010948a03d0105bd3d337b4840021290c0b004b4be0701057d0f687691800424200109d4464041af6d8de88f04242001090c4b60a6d615f499ae58a7250109484002cb22a0a02f6b7d3b5b09484002121896c0c1ac2be80743efc012908004242081fe0828e8fdb1d4920424200109486058025bac2be85be0b8480212908004243015020afa54d6947e4a400212908004b610e841d0b75877910424200109484002a31050d047c1ec20129080042420816109542fe8c34e5feb12908004242081791050d0e7b11e9d8504242001092c9cc0c2057de16bdfe94b40021290c06c0828e8b359954ea46202af0bdf3e1bf173a7e3e723dd2796fe39fdffb045c4fec391ff40c46b231a242081851150d0075ce19a5e14810b63b6086b11db2cd82f8c658f8af825a763247b85d23fa7ecc344ec3f3aac3e35e2bb23323efe44d62001092c8100078225ccd3394aa00f0217871144f238d1be3796b13f15b18de2c680d8ee13371adcb0007fca38f87cfb8676564b40023320c00e3f83692c710ace794402ff1763218c7747ca3ed346b411d2f3a35fe9438a8d7d227d77895c7ac7df187615e8f71551a21e9f9853140d1290c05c08705099cb5c9c8704fa2680f021805fb6c130cb88b4db24da5c0affcc86fe43559f0ac3ecdb8838111fa36a15a8634ed473c561b5c08c0424305d02ecf4d3f55ecf0723b060c39cb9227444842fa340fca82b91fd877808d1ce7e9d94c7c7e2335f3e985be9c332e655caa61290c04409b0334fd475dd96406f045e10968ad071e61ac55540fc5e192504717d59544f2ef0e583fd9ef9303726405951878451021326c08e3c61f7757d9a04aaf1ba9c8ddf1c1e217091ac0202471dfbc84b56b5f3ca3037457d5eebd4d92c98003bf482a7efd41748604967e3bbac5e8e018afa2ea46c2381ca09b03357eea2ee49a01d810dad977e36be014b53cd7140516f50f82181e91260479eaef77a2e8193096cfb6d9c4beac439fc367e3289ed2d3816645187dbf61e2e958004aa22c04e5c95433a23811e08dc11361024040ac18ee22ae4dfc65795bb6766dd92e301cc9824dc789e9dbc51021298000176e009b8a98b12d889c0fdd10a417a62a40852244da08e32d1b3f106c9c68f7c4ce055b21b1bba400212a88b40de79ebf24c6f24b03b81f2fb382f77c9bd384b47c427b39d67e70f98e71fbd94e16158f2a6129040c5043cd055bc7274ed4402080f67dfeb67dde5b23acf5c9f68c4066711e0cc1cae2ce00b113cc91b2520818a0928e815af1c5ddb4800814170d6051b814780d6057ea3a1652d6835db7c6c20ffd7ad7adb580212189d003beae8833aa004f62450847c7dbb7d28ec21e49c5946d6d01381ff4976be2be5cd4a40021512583f3056e8a22e49e088df713923cfdb2be53b830d427e6ea486fe093c254cc23e9226e47c53913fcc4b40028725900f9087f5c4d1257036010404e146b4cb52caef8802dbee15911a8625907fd6c8eb61d851b52e0109b426c041b175273b486040023f13b63709f92b6219dbecb322358c4780f531de68c78e64a504247012010e8e27b571b904c620f0f61804e1f8ed48f3992067e4d7471ddbea2f446a189fc0ffa6217f30e5cd4a40021511e02059913bbab2500208f9b7c7dcd7859c32dbe8dfc632c3e1085c9986be25e567937522129803010e9673988773982e01cec011ee32835276db2c44ea4af3baaacb33bd91c0c20978d05cf80670c0e9bf27c646bc23690279c4c26db2c1e1c77c083813098c43c083e7389c1de54c02bcaaf519a98a4bee6e8b098859094840026d0978106d4bccf65d09f07298fc2637deee961f8dea6adffec312e04acab02368bd15011b4ba01050d00b09d33108ac9f89df1683f6f576376c2336a461d6301001be800d645ab312904017020a7a177af66d4300a1e537f2d287fcd5a5d0217d20fa22e4d88bac61000277259ba752deecec0938c1291150d0a7b4b6a6e9ebf3c3ed2cb8391f8b3a052edf9f972c60db6d3a01e9297b594f76342301090c48c083df8070357dc49dec7f9c38f429b89cf1e7ed77bd9c8635db9180573f3a02b4fbf104aced97403e20f66b596b4b2730e49dec887716998f076c6fac0b0806094860b90414f4e5aefb2167cea5f0a1ee645f177384dd4bc243aecda323181fc51f5758223148600a0496e7a382bebc753ef48c11dcbc5ddd1a03f679277b119730bb121af246094840028b26900fbc8b06e1e47b218098af0beeb5bd583e3a3ace764fa635b32301cfd0770465b3f913a871860a7a8d6b65ba3ead8b795f3351ccfb22d9cd8ecfa077e3676f090c4a40411f14efa28c7f34cd9667c353b1535631ef84af73e7db93059f414f30cc4a603802fb5956d0f7e366afb3095c9aaa2e48f92e59c5bc0bbd7efa3eb91f335a9180048626a0a00f4d7839f6cbe5f63e7f672d36a198f3948de31090fb389c1d45029d09ec2ae89d07d2c0ac09f0cc7999607e4d68a9db27e5ecbcf47b6fc9984a40021290c0f10414f4e3b958db8e407ea9cb15edba6e6c9dcf0cafd9d8ca054312e07d02653df479e565489fb52d81c512a843d0178b7f3613effba0efd9f9e1370dee68cfc7879c3fbc777a2001099c45c09df42c2456b424c081bf74794bc9744ccb1704cc78760e8571233fa1e4ab2e797d8ceb89a34940023b135882a0ef0cc3867b11c807feefdbcbc2999d3c3b3f93c7d8a58762c0fcdade1ba36c908004264040419fc04a9a888b7dfdc69acf063d3b1f77e5f32e8173d290af8dfc2d110d1290c0040828e85d57d2b2fb73d35421f0fc92e9907a76de015ec7aeaf8ffef99fdcfc7b947f34a2410212980801057d222baa5237f3f6f3a61e7cf4ecbc07887b987841f4b92962090f46e6eb221a2420810911c807e409b9bd1857a732d17c66bdafcfd986cf9def4b71bf7e37a76edce4785e2a9b958004264240419fc88aaad0cd2cc0f9c6b87d5df5ec7c5f72ddfae57b1ff809a5af7f75dbcd2b7b4b4002ad0928e8ad91cda843b7a96401ee66e9e8287f39f8745763f6df9940e64e3edfddbeb3111b4a4002751050d0eb580f53f3e265c961842015f7cae62f078fddcb829dda1260bd15ee9ca5f77195a5ad0fb69780047a24a0a0f7087341a67e31cd759310a4265bb30fa4a5084b2a9a1d88c0ba987b1c1808b4662530260177e43169cf67ac7c66d77556f9062cb7c7ae344feeaf989fccc816129824010fa0935c6d0775fa5fd3e888432a76cab63b3bef34d4223bf33a5718e72f63eeff8bdc149cf45c09b843cf75cd0e37affc7c72d79ba8f21782570de7f2e22dc339af2b84dd7d7ff19b8500e646c09d7a6e6b745af329678b78fd937c5412e7e2c6bd3111c43b73e6d134f7fb006390c0dc08b863cf6d8d0e3f1fcef6fa1a057129b6788f78c99b7627c07aba309941d86f88723e538fa2410212980b01057d2e6b72bc796441e0ad625d46ceb62eed6268527d8775f66fc23ce29dcfca1177f6f537c632830424305302ece4339d9ad31a81409fdb4f16a0115c9fe5105cf178f6dacc10f8ae8f16ae99b4280109d448a0cf03728df3d3a761087006886544f813643ac462ab8389c5777d4c102867e1916d025c593fcf694a7e484002b327a0a0cf7e150f32c17c03db251d47784deacf19662a9add81003f7b7c2ada21de913481d7e7ba6f3728fc90c07208b8d32f675df739531e31e38cb0d8ccf952b76bfa63a9e13edbe35f447fc6e78cb44da4cf7ae40b05cf6b2390b7855dfe477824d506fccf97d3993fc23edceb73ab45a1631290c03e0750a9490002594810912e77a92344d86c133933a5dff74427c68fa455a0cf7a647fe0463d2e613f2dacdd1491318e8b8829912f011f897663868763307cc2ffc836011ef8df14fc9080049647c003c0f2d6799f33feda64ecb2946f9b45a04a9f9c2f75c7a5f90b05cb11b836913e5d22624a641fba3c0c95b111f8280e16f81291ffc529e33e3e46cb75519c64d0690948a003010e461dbadb75e104fe23e68fc044d2849c6f2a76fc3837b5db47988ab0b23def1ae9b36be4ea0373433c89c9ddb3b28c4f1b227dce6ab067055701b089cfc5045f1e18efee52612a01092c97000783e5cede99f74180336584065b884dd7bbdeb183bd2bc85412bf3cfc609eec2f44e6b91e3f186df03b9255a00d7544c4fd97564bda65106eae02e45ed8e6e7815c677e1b01974960e6043838cd7c8a4e6f0402df96c6d8f7ae77040ae12ba63e1c99fb236e0ab9ed6f6e6a3462fd553116fb13f3785be4b37f513ca2fe6591a11e717f6be44f0a374603da6337b24da02fb69a821f129080040a817ca02875a612684be01fa2034213491338a36c322d3fd81eb39df3a33f779d477256a06da9fcd992a924e5e52ef887f0fe72f8842847b20ad45f1f25ea99effb22bf1e60f886b5ca0f45992b0591182a23a03b123838010e3a07774207664100a141a0980cdb158244be6dc40e776c977e5c5646f44a39a79f4c05fe11492a56937d7978020f449c5818457513a8bb3a72d4334f2279fa44751328d3eecaa6e487042420816308e483c6318bad92402b026c4f880f9dc8ef2beadc18c773e0d8212266081df91c2f4a85fc8f4852757559b8301f7e135f9f13f5c4ec345728e893ebcc2f8d80f395c00e043c50ec00c926ad08b04df521ea9cb56671238f5dde82961de277e9525e17c8525f63fab11d9de2cb0df3def7cbd18ec3d84c0212983a010ebe539f83fed74780ed0a11c233f25d841621c74e89174406db45d85f7aba1c4973e3d9af93a938de4b7104b200000d994944415417bec18339c0268aab401df3bd276ac847b20ab4a58e48ffd5023312e848c0ee3321c041622653711a951160db427c700b91229f7f1ba77ed758fae7f659d819ab2ce326b492af29e50c1b06bc9695f914dfa8e3b23a75651e3c29409eba774743da44b20ad4534744dcff60b5c48c0424b058021c34163b79273e3801b62f44a70cc40d6f08507eccad2c3b29c55611b2dcb6083b764bfdae97b34bfba1d287c230f327e27f1457813ae643fd39abdab3335f1355b4a1edcd91a75f24ab40fd8f44897a18fc4be40d12a887809e8c468003c5688339d02209b08df1cf4ecae411a0774461dfb375ec6103010b33ab407d295c5a320748791c0d61c5bf75a1a68e37bee17ff677573779b73cfde85f443cf7a5fe1ba28271f081b1a26890800496408083c312e6e91c0f4be071313c6283d044b609e56cbd29ecf1c1b68b4d84ebb8ee8c45643997bb3f705ca396755c1ac7163689d85f8fbc3006bfb269da5287cf4fc80b3ae4ff30fa620fbb44c688aa55a08e3be9f18f650fae969891c07c083893448003422a9a95c0a004d8de1e4823203a08cebe67eb98e28b0176102dcaeb91658cfbd458c05825d21e71be33ea77116afaf14c3cb6b0498cae1b03ed6943c4c78d0d7b5ac0188c45646ed92c75a7a2029f58f6ab91374840023323c0c1696653723a9513e0376f04067129ae2246084d974be5d8c0eeadc5e809296dd9fe39636e23d4eb66990711fff962725d3428b6237b905058e0075fa0f0af3842ddaf44017f23314840021b094c6c0107b489b9acbb3321c0b6b7fedb3a37b3218a5da6786d74fe78c412c82362083d2296c5adb4392ea51d913ef8f473d1083beb91791011519e197f67b4ab29f0050afff09bb914df28333fae52943a53094860c204d8d127ecbeae4f9cc0b6dfd6f7b913bee0b8ac64222d67fd083da2cb368f989d146947a40f42fd5b616bea81b9f09fe310f23217e648999f1d4a9da90424303c81de476067eedda80625d09200dbe1fad97a973be1193e0bb067a110f962fc6824f0feea4811f2489ac0cf0e94ef6a4a7e4840029323c08e3d39a775789604b69dad3f658f1973891c81a22bdbf97f9331ae08f01fdee0b2fedc7a3983e76efd556333129040fd04d8a1575e9a91400504d826d7cfd6ff2bfce277ec485a056c950e57458667b723312402df14797e7ec8cca3eaa83c4fff3c0a460948a07e02f98057bfb77ab81402dbced6dbfeb69e5f05eb2b52376f4185f9fa8d737f125d725d140d1290408d044614f41aa7af4f951360fbcc678e9c49b6fd6dfde53147cef0236982e2d460d8f8c18d73702e3f57d0b094bd17011a4609544a800366a5aee996041a02e5cc310b0ca28330ef2a304f0b4bb48fa4f98f6cbbf6a3fd5223c78622e4850175ac87cf940a530948a01e02eca0f578d3c113bbce9e00dbeaa7d32c111bea10182282fdc369f97a962f01b4a39e7e7dbc0a165b738fb0e28981c28ef99e1b1f94ff335283042450090176d64a5cd10d099c48a0fcebd1f5b79fd111817f6d64101ac4fdef23bf1ef2f6ceab60bd496e9dd0f1659e18801d77c6e7165f150558bf2e52830424706002eca40776610ac3eb636504f2dbcf78031c229e5d44dc9f1515d42338bc812e8a4df026b906c35e1f3cbb0edbfc8f5e28bf30acc1f999911a242081031150d00f04de617b23c01be0d88e8bb020e2d938f5bc2d8e7a44877f4ce24d729950fbfc79d105aef08c6c1328f3dadb5cd72cf043021218870007c2714672948d045cd01b813f0a4b6cd3880b97d4d7c5857a7e4b6759346d0275bef6b441d1fa0396f0e3cb52e95ccade785888984a6024021cfc461aca6124302a01de0c5704079141dcb3f0646778ed2902b4cf1be9b29da5e6398edc1093cf7ca9a37c5fd41b2420811108b0d38d308c431c8e80239f2680b8b3bd23ee9c912336a7173509cbb8144f3de2fffb4dad1fbb1278633484e15b22cd811b1961facfb9d2bc0424d03f0176c0fead6a510275133827dc63db47dc3f1cf9f540fd4f45254284b8fb7856c0d8317c6fb4831fffb636b2abf08d918365240609486008021cd486b0abcd851098c1349f1c73e0cc3c926303e2c4e35945dcef3fb69595eb042e8b0ad8e577f0532e1c2f8fe5060948a047020a7a8f3035355902f94d724c02d1b92e32a491ac0282747e94a8e76c338b55541b8e21f0e8a8831bcc22db04ca1f891cf72d4462908004fa20a0a0f741511b031118d52cbfb117d14170fe294667ff204f44c0a36a15a82b7de85722ed8888d53dabd6660a4b38151ad451f655b28588a9043a106087ead0ddae12981501f60704a64c8a7c79590ae28d8813116b969576396539115b17c502dae588d81339bb7f692c5f5a80cbefc6a461124913caab6479495053e1870424d09e003b57fb5ef690c00c086c9802fb04625b16f3b2941795c2e994c7dc6887707f4bd41581cf2215d5c706fa10f982f06bd1823e2522f444ec7d2296cd35bc382606bf3b22cde19a2830f7480c1290405b02ec546dfbd85e027327c0efbe9f4c937c75e4ff2ce271e11fa3b2083cfb13629de3ddb11c912ea21dc58da1f4c3ce25d1aaf4292976887ce198c333f34f8a3932671e238c6c1398bba2dea0f04302ed08b0f3b4eb616b092c830097cbf3ddefdf1fd35effe72451b529acea1f1f39cec6d9d78808588e885711ec68ba35947ed8c3b7d26fac942f13db227321f285e3e198095f8ade1fe91b226e0b3c46c8dc9807ede0841df2460948604702ec383b36b59904164780bbdfdf9c667d75e4ef8dd867d87676cf5808284247ec73dc7d6c21badb22c713225f38b8caf1b818e4e9116f8c88ff27456c47d3266087f6ccbfa9f0430212d84e809d667b0b974a60d9049e1bd37f49c4122e8c4cbe441cc5c1c2c5611971643f2522784d8cfa7dd29ba3df6d11791d2b73e02c18c124229edb6274334840023513e02051b37ffa26811a08bc329cf8e6882570568d0896f254d29bc251ae32f0a584cbdccc832f0c448e05dbe23e5f20fae8834fe1b64102123889803bcb49845c2e812f127857240854244d203f45516f9cdffee1520948608a0414f429ae357d3e2401849c4bd3f890f3948d129080040e4640413f187a079e3001f69b22ea4c83fc13c8184f26600b09486018021c9886b1ac5509cc9b00fb0e8f669559de1999eb231a242001091c840007a5830ceca012980181533187fcdfd7de1ae57c477c140de3127034092c978082bedc75efccfb21f09830c3d979244d78457cfe69448304242081510928e8a3e276b09912b822e6f56f114bf881c8f0dfda2231cc8980739140cd0414f49ad78ebe4d89c0d787b36f8a5802cfadf37ad6523695800424302801057d50bc1a5f1881e7c57c7f3e6209fc03155edf5acaa612d842c04512e8464041efc6cfde125827f01b51f1ec8825f056b6874ac154021290c0500414f4a1c86a77c904de16937f62c41278cd2aef4d2f6553098c4ec001e74f40419fff3a7686872170570ccb9be4226902fb1aaf8a7d4e53f24302129040cf0438c8f46c52731290402280a8f32639aac8ff556410f6480c12980b01e751030105bd86b5a00f7327c07ef6409a24c28ec8f32f4c53f524b2df1a5ede1af119110d129040450438d054e48eae4860b6042e889921e4f9b774fe7d29c27e4f2c9b42f8e970f2ed11af89c8bf618dc42081e10938c26e0414f4dd38d94a027d1140c4af0a630879244db8283e29bf2fd25ac3ef8563448e19af8ffc9f4734484002151160e7acc81d5d91c022087c3066c9bef7dc4811f2489ac0592fe5bf6c4af57cfc4eb8c2d9792447bc11ef87c81825300f02f399050795f9ccc69948605a04de1ceeb20fbe2ad21cbe3b0a083bef858fec41c23363545e5f7b5fa42f8e48786f7cf046bc480c1290406d043898d4e693fe486069047e2226ccefebef8c3407fe731b77c4df922b07ce7f2aecf365025f787ded63a34cb83d3ef8ed3c12830424b02b8131db29e863d2762c096c27705d2c46d83f146909946f880222fb60a4e7471c2270358031f8ef71c53e77e61761ffca52692a0109d4494041af73bde8d5b2095c19d347c8b9c41dd9553815b9fb2322bc9f8df4fd11db061e37fbbbe87477446c608bc8d580a86ac21df1c9f8dc99cf978c7745d92001095447e04c8714f433795892404d04b8c48db012f3e36ef8f8a8f8787a44c4b84d7c4ff4f98e881747c4462467841745e949110d1290c0c40828e8135b61babb58023cee86b0ff7810f85844443c924e812f093c03cf19fbb56109fbaf89d42001094c9040df823e4104ba2c8149117875787b7944f65d04b84be44bc22561eb3b23f2f6b7480c1290c05409705098aaeffa2d01094840021290c06902d312f4d34e9b484002129080042470260105fd4c1e96242001094840029324a0a03fb2dacc49400212908004264b40419fecaad371094840021290c0230414f447580c9bd3ba0424200109486040020afa8070352d010948400212188b80823e16e961c7d1ba04242001092c9c8082bef00dc0e94b40021290c03c0828e8f3588fc3ce42eb1290800424503d0105bdfa55a48312908004242081930928e82733b2c5b004b42e01094840023d1050d07b80a809094840021290c0a10928e8875e038e3f2c01ad4b400212580801057d212bda694a40021290c0bc0928e8f35ebfce6e58025a97800424500d0105bd9a55a12312908004242081fd0928e8fbb3b3a7048625a075094840022d0828e82d60d954021290800424502b0105bdd635a35f12189680d6252081991150d067b6429d8e04242001092c938082beccf5eeac25302c01ad4b4002a31350d04747ee8012908004242081fe097c010000ffff58f3a0ff000000064944415403009e2ec3be15208c150000000049454e44ae426082, '2025-09-05 23:27:06');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grupos`
--

CREATE TABLE `grupos` (
  `id` int(11) NOT NULL,
  `nombre_grupo` varchar(10) NOT NULL,
  `activo` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `grupos`
--

INSERT INTO `grupos` (`id`, `nombre_grupo`, `activo`) VALUES
(1, '0-1', 1),
(2, '0-2', 1),
(3, '0-3', 1),
(4, '0-4', 1),
(5, '1-1', 1),
(6, '1-2', 1),
(7, '1-3', 1),
(8, '2-1', 1),
(9, '2-2', 1),
(10, '2-3', 1),
(11, '3-1', 1),
(12, '3-2', 1),
(13, '3-3', 1),
(14, '4-1', 1),
(15, '4-2', 1),
(16, '4-3', 1),
(17, '5-1', 1),
(18, '5-2', 1),
(19, '5-3', 1),
(20, '6-1', 1),
(21, '6-2', 1),
(22, '6-3', 1),
(23, '6-4', 1),
(24, '7-1', 1),
(25, '7-2', 1),
(26, '7-3', 1),
(27, '8-1', 1),
(28, '8-2', 1),
(29, '8-3', 1),
(30, '9-1', 1),
(31, '9-2', 1),
(32, '9-3', 1),
(33, '10-1', 1),
(34, '10-2', 1),
(35, '10-3', 1),
(36, '11-1', 1),
(37, '11-2', 1),
(38, '11-3', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro_disciplinario`
--

CREATE TABLE `registro_disciplinario` (
  `id` int(11) NOT NULL,
  `fecha_registro` date NOT NULL,
  `estudiante_nombre` varchar(255) NOT NULL,
  `estudiante_grupo` varchar(10) NOT NULL,
  `descripcion_falta` text NOT NULL,
  `tipo_falta` enum('leve','grave','muy_grave') NOT NULL,
  `sancion_aplicada` text DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  `docente_nombre` varchar(255) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `firma_estudiante` tinyint(1) DEFAULT 0,
  `firma_docente` tinyint(1) DEFAULT 0,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `registro_disciplinario`
--

INSERT INTO `registro_disciplinario` (`id`, `fecha_registro`, `estudiante_nombre`, `estudiante_grupo`, `descripcion_falta`, `tipo_falta`, `sancion_aplicada`, `observaciones`, `docente_nombre`, `fecha_creacion`, `fecha_modificacion`, `firma_estudiante`, `firma_docente`, `fecha_actualizacion`) VALUES
(1, '2025-01-15', 'AGUDELO ZAPATA MARIA SALOME', '11-2', 'Llegada tarde al aula después del descanso sin justificación válida', 'leve', 'Amonestación verbal y registro en el observador', 'Estudiante comprometida académicamente, situación aislada', 'Prof. María González', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(2, '2025-01-18', 'BEDOYA COLORADO DANIEL', '11-2', 'No presentó la tarea de matemáticas asignada para la fecha', 'leve', 'Presentar la tarea al día siguiente con punto menos', 'Se acordó horario de refuerzo académico', 'Prof. Carlos Martínez', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(3, '2025-01-20', 'CANO BOLIVAR SOFIA', '11-2', 'Uso del celular durante la clase de química sin autorización', 'leve', 'Decomiso temporal del dispositivo y llamada de atención', 'Primera vez que presenta este comportamiento', 'Prof. Ana Rodríguez', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(4, '2025-01-22', 'LOPEZ LONDOÑO KEVIN ANDRES', '11-2', 'Conversaciones constantes que interrumpen el desarrollo de la clase', 'leve', 'Cambio de puesto y compromiso escrito', 'Estudiante reconoce la falta y se compromete a mejorar', 'Prof. Luis Hernández', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(5, '2025-01-25', 'TAMAYO RAMIREZ JUAN JOSE', '11-2', 'Llegada tarde al colegio sin excusa médica o familiar', 'leve', 'Registro en el sistema y notificación a padres', 'Situación de transporte público, se buscaron alternativas', 'Coordinador José Pérez', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(6, '2025-01-16', 'GUERRA GARCES MIGUEL ANGEL', '11-2', 'Altercado verbal con un compañero durante el descanso', 'grave', 'Suspensión de un día y trabajo comunitario en el colegio', 'Diálogo restaurativo con el compañero afectado', 'Coordinador José Pérez', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(7, '2025-01-19', 'OSPINA CHAVARRIA LUIS MIGUEL', '11-2', 'Salida del aula sin autorización del docente durante clase', 'grave', 'Suspensión interna por medio día y compromiso académico-disciplinario', 'Acudiente citado, se establecieron acuerdos de seguimiento', 'Prof. Carmen Silva', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(8, '2025-01-23', 'QUINTERO CLAVIJO STIVEN', '11-2', 'Irrespeto hacia el docente con vocabulario inadecuado', 'grave', 'Suspensión de dos días y disculpas públicas al docente', 'Trabajo de reflexión sobre valores y respeto', 'Prof. Diana López', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(9, '2025-01-26', 'RAMIREZ PINEDA EMANUEL', '11-2', 'Daño intencional a material didáctico del laboratorio', 'grave', 'Reposición del material dañado y trabajo de mantenimiento', 'Estudiante asume responsabilidad y repone el elemento', 'Prof. Roberto Gómez', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(10, '2025-01-17', 'HERNANDEZ TENORIO SEBASTIAN', '11-2', 'Agresión física a un compañero durante una discusión en el patio', 'muy_grave', 'Suspensión de 3 días, compromiso de convivencia y remisión a orientación escolar', 'Proceso de mediación escolar iniciado, seguimiento psicológico', 'Rector Carlos Mendoza', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(11, '2025-01-21', 'DAVID ZAPATA MIGUEL ANGEL', '11-2', 'Porte y consumo de cigarrillo electrónico dentro de las instalaciones', 'muy_grave', 'Suspensión de 5 días, compromiso final de convivencia y charla preventiva', 'Citación inmediata de acudientes, trabajo con orientación escolar', 'Coordinador José Pérez', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(12, '2025-01-24', 'ALVAREZ CALLE DANNA ISABELLA', '11-2', 'Inasistencia injustificada a evaluación programada', 'leve', 'Presentación de la evaluación con penalización del 10%', 'Se verificó situación familiar, se autorizó nueva fecha', 'Prof. Sandra Torres', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(13, '2025-01-27', 'BOTERO CARDONA JUAN JOSE', '11-2', 'Participación en desorden grupal durante la formación general', 'grave', 'Trabajo comunitario de limpieza y organización por una semana', 'Liderazgo negativo, se trabajará en liderazgo positivo', 'Coordinador José Pérez', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(14, '2025-01-28', 'COLORADO GALLEGO ALEJANDRA', '11-2', 'No cumplimiento reiterado con el uniforme escolar completo', 'leve', 'Notificación a padres y seguimiento semanal por coordinación', 'Situación económica familiar, se buscó apoyo institucional', 'Coordinador José Pérez', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(15, '2025-01-29', 'GIRALDO GIRALDO YISELA ANDREA', '11-2', 'Plagio en trabajo de investigación de ciencias sociales', 'grave', 'Anulación del trabajo y elaboración de nuevo proyecto con seguimiento', 'Charla sobre honestidad académica y citas bibliográficas', 'Prof. Miguel Vargas', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(16, '2025-01-30', 'LONDOÑO DUQUE ISABELLA', '11-2', 'Distracción constante y perturbación del ambiente de clase', 'leve', 'Diálogo formativo y establecimiento de metas de atención', 'Se descartaron problemas de aprendizaje, compromiso de mejora', 'Prof. Patricia Ruiz', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(17, '2025-02-01', 'MOSQUERA PANIAGUA KENDRY NICOL', '11-2', 'Uso inadecuado de redes sociales para publicar contenido del colegio', 'grave', 'Eliminación del contenido y charla sobre uso responsable de redes', 'Trabajo sobre ciudadanía digital y privacidad', 'Coordinador José Pérez', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(18, '2025-02-02', 'OCHOA ALZATE MARIANGEL', '11-2', 'Falta de respeto hacia compañeras con comentarios discriminatorios', 'grave', 'Suspensión de 1 día y taller de convivencia y respeto a la diversidad', 'Proceso de sensibilización y disculpas restaurativas', 'Orientadora Clara Jiménez', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(19, '2025-02-03', 'ORTIZ GUERRA EMANUEL', '11-2', 'Llegada en estado inadecuado (presuntamente bajo efectos de sustancias)', 'muy_grave', 'Suspensión inmediata, exámenes médicos y compromiso final de convivencia', 'Intervención de orientación escolar y remisión a especialista', 'Rector Carlos Mendoza', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(20, '2025-02-04', 'OSPINA VELASQUEZ MARÍA JOSÉ', '11-2', 'Abandono de clases sin autorización durante jornada académica', 'grave', 'Suspensión interna y recuperación de contenidos perdidos', 'Seguimiento académico especial y apoyo psicológico', 'Coordinador José Pérez', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(21, '2025-02-05', 'OSSA DAVID SIMON', '11-2', 'Falta de entrega reiterada de trabajos y evaluaciones', 'leve', 'Plan de recuperación académica con horarios especiales', 'Dificultades de organización personal, apoyo de orientación', 'Prof. Elena Castro', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(22, '2025-02-06', 'PEREZ GUTIERREZ EMANUEL', '11-2', 'Vocabulario soez e irrespeto hacia personal de servicios generales', 'grave', 'Disculpas públicas, trabajo comunitario y reflexión sobre valores', 'Trabajo sobre respeto y valoración del trabajo de otros', 'Coordinador José Pérez', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(23, '2025-02-07', 'SALAZAR CORTES DAVID', '11-2', 'Manipulación y daño de elementos tecnológicos del aula', 'grave', 'Reposición de elementos dañados y restricción de uso de tecnología', 'Capacitación sobre uso adecuado de recursos tecnológicos', 'Prof. Andrés Moreno', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(24, '2025-02-08', 'SEPULVEDA CALLEJAS MICHELLE', '11-2', 'Inasistencia a citación de acudientes sin justificación', 'leve', 'Nueva citación con carácter obligatorio y seguimiento especial', 'Situación familiar compleja, intervención de trabajo social', 'Coordinador José Pérez', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(25, '2025-02-10', 'USUGA CRUZ ISABELLA', '11-2', 'Comportamiento disruptivo durante acto cívico institucional', 'leve', 'Reflexión escrita sobre respeto a símbolos patrios y compromiso', 'Primera llamada de atención, estudiante reconoce la falta', 'Prof. Gloria Ramírez', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(26, '2025-02-11', 'CALLE RIOS JOHAN', '11-2', 'Incumplimiento reiterado de normas de bioseguridad', 'leve', 'Charla sobre autocuidado y responsabilidad social', 'Sensibilización sobre cuidado personal y colectivo', 'Enfermera Isabel Morales', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(27, '2025-02-12', 'CAMPO MESA JUAN JOSE', '11-2', 'Participación en riña verbal que casi escala a agresión física', 'grave', 'Mediación escolar, suspensión de 2 días y compromiso de no repetición', 'Trabajo en resolución pacífica de conflictos', 'Coordinador José Pérez', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(28, '2025-02-13', 'CAÑAS MENESES SIMON', '11-2', 'Comercialización no autorizada de productos dentro del colegio', 'grave', 'Decomiso de productos, suspensión de 1 día y charla sobre reglamento', 'Emprendimiento mal encauzado, orientación sobre normatividad', 'Coordinador José Pérez', '2025-09-05 22:44:03', '2025-09-05 22:44:03', 0, 0, '2025-09-05 23:24:39'),
(29, '2025-02-14', 'BEDOYA SANCHEZ ANA SOFIA', '11-2', 'Suplantación de firma de acudiente en documento escolar', 'leve', 'Suspensión de 3 días, compromiso final y citación inmediata de acudientes', 'Falta grave a la honestidad, proceso de reflexión ética', 'Rector Carlos Mendoza', '2025-09-05 22:44:03', '2025-09-05 23:28:40', 0, 0, '2025-09-05 23:28:40'),
(30, '2025-02-15', 'AGUINAGA BARRIENTOS CHRISTOPHER REY', '11-2', 'Perturbación del orden durante evaluación grupal', 'grave', 'Presentación individual de la evaluación y compromiso de mejora', 'Ansiedad ante evaluaciones, remisión a orientación', 'Prof. Fernando Álvarez', '2025-09-05 22:44:03', '2025-09-05 23:28:32', 0, 0, '2025-09-05 23:28:32');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `contrasena` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `contrasena`) VALUES
(1, 'admin', '$2y$10$XL9RWt8vxswXSNPsNrukaOe5AIBOPgkSftZ/TfaTlMirmVoiVaDUC'),
(2, '1011397895', '$2y$10$6IE3YeVWd3re9PuttOqL.OICHjJWlbmfkbAPLIizmLfTyaiCfmM7m'),
(3, '1022148001', '$2y$10$uAuIYPKQJvmp81SwpUPIJOF.sBgea1QWkcqTU9V9T6kxOtnzBibGi'),
(4, '1034920397', '$2y$10$4/tlxzOs/CBIln4Rm27ySOn/lTvncSol9NDX1T6sHGo1kJa7pABo6'),
(5, '1017930192', '$2y$10$C3r7Hqq74ZUJnocMQviT/O2i0hbM/cOsXK9e840tNAsAyYeBUYijC'),
(6, 'Andrés David', '$2y$10$7h0r0VIjWhXQOW2N61L.mOTbbPCRA5bk4WCTYSWC1rgJRafYpux2K');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `asistencias`
--
ALTER TABLE `asistencias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `firmas_digitales`
--
ALTER TABLE `firmas_digitales`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_firma` (`registro_id`,`tipo_firma`),
  ADD KEY `idx_registro_id` (`registro_id`),
  ADD KEY `idx_tipo_firma` (`tipo_firma`);

--
-- Indices de la tabla `grupos`
--
ALTER TABLE `grupos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre_grupo` (`nombre_grupo`);

--
-- Indices de la tabla `registro_disciplinario`
--
ALTER TABLE `registro_disciplinario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_registro_fecha` (`fecha_registro`),
  ADD KEY `idx_registro_grupo` (`estudiante_grupo`),
  ADD KEY `idx_registro_estudiante` (`estudiante_nombre`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `asistencias`
--
ALTER TABLE `asistencias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;

--
-- AUTO_INCREMENT de la tabla `firmas_digitales`
--
ALTER TABLE `firmas_digitales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `grupos`
--
ALTER TABLE `grupos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT de la tabla `registro_disciplinario`
--
ALTER TABLE `registro_disciplinario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

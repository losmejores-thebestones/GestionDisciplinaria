<?php
session_start();

// Script de depuración para verificar el funcionamiento de las firmas
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Verificar sesión
if (!isset($_SESSION['usuario'])) {
    die('Error: No hay sesión activa. <a href="index.php">Iniciar sesión</a>');
}

// Configuración de base de datos
$host = 'localhost';
$dbname = 'sistema_disciplinario';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die('Error de conexión: ' . $e->getMessage());
}

echo "<h1>Debug - Sistema de Firmas Digitales</h1>";
echo "<p>Usuario actual: " . $_SESSION['usuario'] . "</p>";

// Verificar estructura de tablas
echo "<h2>1. Verificación de Tablas</h2>";
try {
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "<p>Tablas existentes: " . implode(', ', $tables) . "</p>";
    
    if (in_array('registro_disciplinario', $tables)) {
        echo "<p>✓ Tabla registro_disciplinario existe</p>";
        $columns = $pdo->query("DESCRIBE registro_disciplinario")->fetchAll(PDO::FETCH_ASSOC);
        echo "<details><summary>Estructura registro_disciplinario</summary><pre>";
        foreach($columns as $col) {
            echo $col['Field'] . " - " . $col['Type'] . "\n";
        }
        echo "</pre></details>";
    } else {
        echo "<p>✗ Tabla registro_disciplinario NO existe</p>";
    }
    
    if (in_array('firmas_digitales', $tables)) {
        echo "<p>✓ Tabla firmas_digitales existe</p>";
        $columns = $pdo->query("DESCRIBE firmas_digitales")->fetchAll(PDO::FETCH_ASSOC);
        echo "<details><summary>Estructura firmas_digitales</summary><pre>";
        foreach($columns as $col) {
            echo $col['Field'] . " - " . $col['Type'] . "\n";
        }
        echo "</pre></details>";
    } else {
        echo "<p>✗ Tabla firmas_digitales NO existe</p>";
    }
} catch(PDOException $e) {
    echo "<p>Error verificando tablas: " . $e->getMessage() . "</p>";
}

// Verificar registros existentes
echo "<h2>2. Registros Existentes</h2>";
try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM registro_disciplinario");
    $count = $stmt->fetch()['total'];
    echo "<p>Total de registros disciplinarios: $count</p>";
    
    if ($count > 0) {
        $stmt = $pdo->query("SELECT * FROM registro_disciplinario ORDER BY id DESC LIMIT 3");
        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo "<h3>Últimos 3 registros:</h3>";
        echo "<table border='1' style='border-collapse: collapse; margin-bottom: 20px;'>";
        echo "<tr><th>ID</th><th>Fecha</th><th>Estudiante</th><th>Grupo</th><th>Firma Est.</th><th>Firma Doc.</th></tr>";
        foreach($records as $record) {
            echo "<tr>";
            echo "<td>" . $record['id'] . "</td>";
            echo "<td>" . $record['fecha_registro'] . "</td>";
            echo "<td>" . $record['estudiante_nombre'] . "</td>";
            echo "<td>" . $record['estudiante_grupo'] . "</td>";
            echo "<td>" . ($record['firma_estudiante'] ? 'Sí' : 'No') . "</td>";
            echo "<td>" . ($record['firma_docente'] ? 'Sí' : 'No') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
} catch(PDOException $e) {
    echo "<p>Error verificando registros: " . $e->getMessage() . "</p>";
}

// Verificar firmas digitales
echo "<h2>3. Firmas Digitales</h2>";
try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM firmas_digitales");
    $count = $stmt->fetch()['total'];
    echo "<p>Total de firmas guardadas: $count</p>";
    
    if ($count > 0) {
        $stmt = $pdo->query("SELECT fd.*, rd.estudiante_nombre FROM firmas_digitales fd 
                            JOIN registro_disciplinario rd ON fd.registro_id = rd.id 
                            ORDER BY fd.fecha_firma DESC LIMIT 5");
        $firmas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo "<h3>Últimas 5 firmas:</h3>";
        echo "<table border='1' style='border-collapse: collapse;'>";
        echo "<tr><th>ID</th><th>Registro ID</th><th>Estudiante</th><th>Tipo</th><th>Fecha</th><th>Tamaño (bytes)</th></tr>";
        foreach($firmas as $firma) {
            echo "<tr>";
            echo "<td>" . $firma['id'] . "</td>";
            echo "<td>" . $firma['registro_id'] . "</td>";
            echo "<td>" . $firma['estudiante_nombre'] . "</td>";
            echo "<td>" . $firma['tipo_firma'] . "</td>";
            echo "<td>" . $firma['fecha_firma'] . "</td>";
            echo "<td>" . strlen($firma['firma_data']) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
} catch(PDOException $e) {
    echo "<p>Error verificando firmas: " . $e->getMessage() . "</p>";
}

// Test de guardado de firma
echo "<h2>4. Test de Guardado de Firma</h2>";
if ($_POST['test_signature'] ?? false) {
    try {
        // Crear un registro de prueba
        $stmt = $pdo->prepare("INSERT INTO registro_disciplinario 
            (fecha_registro, estudiante_nombre, estudiante_grupo, descripcion_falta, tipo_falta, docente_nombre) 
            VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            date('Y-m-d'),
            'TEST - ' . date('H:i:s'),
            '0-1',
            'Prueba del sistema de firmas',
            'leve',
            'Sistema'
        ]);
        $test_record_id = $pdo->lastInsertId();
        echo "<p>✓ Registro de prueba creado con ID: $test_record_id</p>";
        
        // Crear una imagen de prueba (cuadrado negro 10x10)
        $test_image = imagecreate(10, 10);
        imagecolorallocate($test_image, 0, 0, 0);
        ob_start();
        imagepng($test_image);
        $test_image_data = ob_get_contents();
        ob_end_clean();
        imagedestroy($test_image);
        
        // Guardar firma de prueba
        $stmt = $pdo->prepare("INSERT INTO firmas_digitales (registro_id, tipo_firma, firma_data, usuario_firma) 
                              VALUES (?, ?, ?, ?)");
        $stmt->execute([$test_record_id, 'estudiante', $test_image_data, $_SESSION['usuario']]);
        echo "<p>✓ Firma de prueba guardada</p>";
        
        // Actualizar estado en registro principal
        $stmt = $pdo->prepare("UPDATE registro_disciplinario SET firma_estudiante = 1 WHERE id = ?");
        $stmt->execute([$test_record_id]);
        echo "<p>✓ Estado de firma actualizado</p>";
        
        // Limpiar datos de prueba
        $stmt = $pdo->prepare("DELETE FROM registro_disciplinario WHERE id = ?");
        $stmt->execute([$test_record_id]);
        echo "<p>✓ Datos de prueba eliminados</p>";
        
    } catch(Exception $e) {
        echo "<p>✗ Error en test: " . $e->getMessage() . "</p>";
    }
} else {
    echo '<form method="post"><input type="hidden" name="test_signature" value="1">
          <button type="submit" style="padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer;">
          Ejecutar Test de Guardado</button></form>';
}

// Test de conectividad AJAX
echo "<h2>5. Test de Conectividad AJAX</h2>";
echo '<div id="ajax-test">
<button onclick="testAjax()" style="padding: 10px 20px; background: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer;">
Test AJAX</button>
<div id="ajax-result" style="margin-top: 10px; padding: 10px; border: 1px solid #ddd; display: none;"></div>
</div>

<script>
async function testAjax() {
    const resultDiv = document.getElementById("ajax-result");
    resultDiv.style.display = "block";
    resultDiv.innerHTML = "Probando conexión AJAX...";
    
    try {
        const response = await fetch("signature_handler.php?action=get_records");
        const data = await response.json();
        
        if (data.success) {
            resultDiv.innerHTML = `✓ AJAX funciona correctamente. Registros encontrados: ${data.records.length}`;
            resultDiv.style.background = "#d4edda";
            resultDiv.style.color = "#155724";
        } else {
            resultDiv.innerHTML = `✗ Error AJAX: ${data.error}`;
            resultDiv.style.background = "#f8d7da";
            resultDiv.style.color = "#721c24";
        }
    } catch (error) {
        resultDiv.innerHTML = `✗ Error de conexión: ${error.message}`;
        resultDiv.style.background = "#f8d7da";
        resultDiv.style.color = "#721c24";
    }
}
</script>';

echo "<h2>6. Información del Servidor</h2>";
echo "<p>PHP Version: " . phpversion() . "</p>";
echo "<p>MySQL Version: " . $pdo->query('SELECT VERSION()')->fetchColumn() . "</p>";
echo "<p>GD Extension: " . (extension_loaded('gd') ? 'Disponible' : 'NO disponible') . "</p>";
echo "<p>Max Upload Size: " . ini_get('upload_max_filesize') . "</p>";
echo "<p>Max Post Size: " . ini_get('post_max_size') . "</p>";

echo "<hr><p><a href='tabla.php'>← Volver al sistema principal</a></p>";
?>
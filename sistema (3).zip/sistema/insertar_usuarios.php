<?php // Indica que comienza código PHP

$conexion = new mysqli("localhost", "root", "", "sistema_disciplinario"); 
// Crea un nuevo objeto de conexión a MySQL usando la extensión mysqli.
// Parámetros: 
// "localhost" → el servidor de la base de datos está en la misma máquina.
// "root" → el usuario de MySQL que se está usando.
// "" → la contraseña del usuario root (aquí está vacía).
// "sistema_disciplinario" → el nombre de la base de datos a la que nos vamos a conectar.

// Verifica si ocurrió algún error de conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error); 
    // Si hubo un error, detiene el script y muestra el mensaje con el detalle del error.
}

// Opcional: borrar datos anteriores para evitar duplicados
$conexion->query("TRUNCATE TABLE usuarios"); 
// Ejecuta una consulta SQL que borra todos los registros de la tabla "usuarios"
// y reinicia el contador de auto_increment. Esto se hace para evitar registros duplicados.

// Array con los usuarios y contraseñas en texto plano antes de cifrarlos
$usuarios = [
    ['admin', '1234'],
    ['1011397895', '1011'],
    ['1022148001', '1022'],
    ['1034920397', '1034'],
    ['1017930192', '1033'],
    ['Andrés David', '1111'],
];

// Bucle que recorre cada usuario dentro del array $usuarios
foreach ($usuarios as $u) {
    $usuario = $u[0]; // Nombre o identificación del usuario
    $contrasena = password_hash($u[1], PASSWORD_DEFAULT); 
    // Se cifra la contraseña usando password_hash con el algoritmo por defecto (actualmente bcrypt).
    // Esto mejora la seguridad, ya que no se guardan contraseñas en texto plano.

    // Prepara una consulta SQL con parámetros (previene inyección SQL)
    $stmt = $conexion->prepare("INSERT INTO usuarios (usuario, contrasena) VALUES (?, ?)");
    if (!$stmt) { 
        die("Error en prepare: " . $conexion->error); 
        // Si no se pudo preparar la consulta, se detiene y muestra el error.
    }

    // Asocia las variables $usuario y $contrasena a los parámetros de la consulta
    // "ss" indica que ambos parámetros son strings (texto).
    $stmt->bind_param("ss", $usuario, $contrasena);

    // Ejecuta la consulta preparada
    if (!$stmt->execute()) {
        echo "Error al insertar usuario $usuario: " . $stmt->error . "<br>";
        // Si hay error en la ejecución, muestra un mensaje de error específico para ese usuario.
    }

    // Cierra la consulta preparada para liberar memoria
    $stmt->close();
}

// Si todo va bien, muestra mensaje de confirmación
echo "Usuarios insertados correctamente con contraseñas seguras.";

// Cierra la conexión a la base de datos
$conexion->close();

?> 

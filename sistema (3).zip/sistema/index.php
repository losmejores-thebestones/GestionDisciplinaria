<?php
session_start(); // <-- añadido para poder usar sesiones en todo el archivo

// Variable para almacenar posibles mensajes de error
$error = "";

// Verifica si el formulario fue enviado con el método POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Incluye el archivo de conexión a la base de datos
    include 'conexion.php';

    // Obtiene y limpia los datos enviados por el formulario
    $usuario = trim($_POST['usuario'] ?? '');
    $contrasena = trim($_POST['contrasena'] ?? '');

    // Validaciones básicas
    if (empty($usuario) || empty($contrasena)) {
        $error = "Por favor, completa todos los campos.";
    } elseif (!ctype_digit($contrasena)) {
        $error = "La contraseña solo debe contener números.";
    } else {
        // Consulta SQL con parámetro preparado
        $sql = "SELECT * FROM usuarios WHERE usuario = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $usuario);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $fila = $result->fetch_assoc();
            if (password_verify($contrasena, $fila['contrasena'])) {
                // --- Añadido para guardar sesión ---
                $_SESSION['usuario'] = $usuario; // Guardar el nombre de usuario en sesión
                header("Location: menu.php");
                exit();
            } else {
                $error = "Contraseña incorrecta";
            }
        } else {
            $error = "Usuario no encontrado";
        }

        $stmt->close();
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" /> <!-- Codificación UTF-8 -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/> <!-- Adaptación móvil -->
  <link rel="icon" href="img/logosantaie.gif" type="image/x-icon"> <!-- Icono de pestaña -->
  <title>Iniciar Sesión | I.E. Santa Teresa</title>
  <!-- Librería de íconos Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  
  <style>
    /* --- REGLAS CSS --- */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box; /* Incluye padding y borde en el tamaño total */
    }

    body {
      height: 100vh;
      background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); /* Fondo degradado */
      display: flex;
      justify-content: center;
      align-items: center;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: white;
      overflow: hidden; /* Oculta partículas que salgan */
      position: relative;
    }

    /* Partículas decorativas */
    .particle {
      position: absolute;
      width: 4px;
      height: 4px;
      background: rgba(255, 255, 255, 0.8);
      border-radius: 50%;
      animation: float 12s infinite ease-in-out;
      opacity: 0.6;
    }

    /* Animación de partículas flotando */
    @keyframes float {
      0% { transform: translateY(100vh) scale(0.3); opacity: 0; }
      10%, 90% { opacity: 1; }
      100% { transform: translateY(-10vh) scale(1); opacity: 0; }
    }

    /* Contenedor del login */
    .login-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      width: 100%;
      max-width: 450px;
      padding: 20px;
      z-index: 10;
    }

    /* Encabezado */
    .login-header {
      text-align: center;
      margin-bottom: 1.5rem;
      animation: slideInDown 0.8s ease-out;
    }

    /* Logo e institución */
    .logo-container {
      display: flex;
      justify-content: center;
      gap: 15px;
      margin-bottom: 1rem;
    }

    .logo {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      transition: transform 0.3s;
    }
    .logo:hover { transform: scale(1.1); }

    .institution-name {
      font-size: 1.8rem;
      font-weight: 700;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }

    /* Contenedor del formulario */
    .form-container {
      background: rgba(255, 255, 255, 0.15);
      border-radius: 25px;
      padding: 3rem 2.5rem;
      backdrop-filter: blur(15px);
      box-shadow: 0 15px 35px rgba(0,0,0,0.1);
      width: 100%;
      animation: slideInUp 0.8s ease-out 0.2s both;
      position: relative;
    }

    /* Campos de entrada */
    .input-group {
      position: relative;
      margin-bottom: 1.8rem;
    }

    .input-group i.fa-user,
    .input-group i.fa-lock {
      position: absolute;
      left: 15px;
      top: 50%;
      transform: translateY(-50%);
      color: rgba(255, 255, 255, 0.7);
    }

    .form-input {
      width: 100%;
      padding: 1rem 1rem 1rem 50px;
      border-radius: 15px;
      background: rgba(255,255,255,0.1);
      color: #fff;
      border: 2px solid rgba(255, 255, 255, 0.2);
      transition: all 0.3s;
    }

    .form-input::placeholder {
      color: white; /* blanco */
      font-weight: 500;
    }

    /* Botón de mostrar/ocultar contraseña */
    .password-toggle {
      position: absolute;
      right: 15px;
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: none;
      cursor: pointer;
      color: rgba(255, 255, 255, 0.7);
    }

    /* Botón de envío */
    .submit-btn {
      width: 100%;
      padding: 1rem;
      background: linear-gradient(135deg, #00c3ff 0%, #3a7bd5 100%);
      color: white;
      font-weight: 600;
      border: none;
      border-radius: 15px;
      cursor: pointer;
    }

    /* Mensaje de error */
    .error-message {
      background: rgba(255, 107, 107, 0.2);
      color: #ff6b6b;
      padding: 1rem;
      border-radius: 12px;
      text-align: center;
      margin-bottom: 1.5rem;
    }
  </style>
</head>
<body>

<script>
  // Generar 50 partículas flotantes
  for (let i = 0; i < 50; i++) {
    const particle = document.createElement('div');
    particle.classList.add('particle');
    particle.style.left = Math.random() * 100 + 'vw'; // Posición horizontal aleatoria
    particle.style.animationDuration = (8 + Math.random() * 8) + 's'; // Duración variable
    particle.style.animationDelay = Math.random() * 15 + 's'; // Retraso aleatorio
    document.body.appendChild(particle);
  }
</script>

<div class="login-container">
  <!-- Encabezado -->
  <div class="login-header">
    <div class="logo-container">
      <img src="img/logosantaie.gif" alt="Logo I.E. Santa Teresa" class="logo">
    </div>
    <h1 class="institution-name">I.E. Santa Teresa</h1>
    <p class="system-subtitle">Sistema de Gestión Disciplinaria</p>
  </div>

  <!-- Formulario de login -->
  <div class="form-container">
    <h2 class="form-title"><i class="fas fa-sign-in-alt"></i> Iniciar Sesión</h2>
    
    <!-- Mostrar mensaje de error si existe -->
    <?php if (!empty($error)): ?>
      <div class="error-message">
        <i class="fas fa-exclamation-circle"></i>
        <?php echo htmlspecialchars($error); ?>
      </div>
    <?php endif; ?>
    
    <!-- Formulario -->
    <form method="POST" autocomplete="off">
      <div class="input-group">
        <input type="text" name="usuario" class="form-input" placeholder="Usuario" required />
        <i class="fas fa-user"></i>
      </div>
      
      <div class="input-group">
        <div class="password-input-container">
          <input type="password" name="contrasena" id="contrasena" class="form-input" placeholder="Contraseña" required />
          <i class="fas fa-lock"></i>
          <button type="button" id="togglePassword" class="password-toggle">
            <i class="fas fa-eye" id="eyeIcon"></i>
          </button>
        </div>
      </div>
      
      <button type="submit" class="submit-btn">
        <i class="fas fa-arrow-right"></i> Acceder al Sistema
      </button>
    </form>
  </div>

  <div class="login-footer">
    <p>&copy; 2025 Institución Educativa Santa Teresa</p>
  </div>
</div>

<script>
  const input = document.getElementById("contrasena");
  const toggle = document.getElementById("togglePassword");
  const eyeIcon = document.getElementById("eyeIcon");

  // Forzar que solo se ingresen números en la contraseña
  input.addEventListener("input", function () {
    this.value = this.value.replace(/[^0-9]/g, "");
  });

  // Mostrar/Ocultar contraseña
  toggle.addEventListener("click", function () {
    const isPassword = input.getAttribute("type") === "password";
    input.setAttribute("type", isPassword ? "text" : "password");
    eyeIcon.className = isPassword ? "fas fa-eye-slash" : "fas fa-eye";
  });
</script>
</body>
</html>

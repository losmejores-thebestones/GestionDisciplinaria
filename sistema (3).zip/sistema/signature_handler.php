<?php
session_start();

// Configuración de errores para depuración
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Headers para JSON
header('Content-Type: application/json');

// Verificar sesión
if (!isset($_SESSION['usuario'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit();
}

// Configuración de base de datos
$host = 'localhost';
$dbname = 'sistema_disciplinario';
$username = 'root'; // Cambiar según tu configuración
$password = ''; // Cambiar según tu configuración

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Error de conexión: ' . $e->getMessage()]);
    exit();
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch($action) {
    case 'save_record':
        saveRecord($pdo);
        break;
    case 'save_signature':
        saveSignature($pdo);
        break;
    case 'get_records':
        getRecords($pdo);
        break;
    case 'delete_record':
        deleteRecord($pdo);
        break;
    case 'get_signature':
        getSignature($pdo);
        break;
    case 'get_record_data':
        getRecordData($pdo);
        break;
    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Acción no válida']);
}

function saveRecord($pdo) {
    try {
        $fecha = $_POST['fecha'] ?? '';
        $estudiante_nombre = $_POST['estudiante_nombre'] ?? '';
        $estudiante_grupo = $_POST['estudiante_grupo'] ?? '';
        $descripcion_falta = $_POST['descripcion_falta'] ?? '';
        $tipo_falta = $_POST['tipo_falta'] ?? '';
        $sancion_aplicada = $_POST['sancion_aplicada'] ?? '';
        $observaciones = $_POST['observaciones'] ?? '';
        $docente_nombre = $_POST['docente_nombre'] ?? '';
        $record_id = $_POST['record_id'] ?? null;

        // Validaciones básicas
        if (empty($fecha) || empty($estudiante_nombre) || empty($estudiante_grupo) || 
            empty($descripcion_falta) || empty($tipo_falta) || empty($docente_nombre)) {
            echo json_encode(['success' => false, 'error' => 'Todos los campos obligatorios deben ser completados']);
            return;
        }

        if ($record_id && !empty($record_id)) {
            // Actualizar registro existente
            $stmt = $pdo->prepare("UPDATE registro_disciplinario SET 
                fecha_registro = ?, estudiante_nombre = ?, estudiante_grupo = ?, 
                descripcion_falta = ?, tipo_falta = ?, sancion_aplicada = ?, 
                observaciones = ?, docente_nombre = ? WHERE id = ?");
            $stmt->execute([$fecha, $estudiante_nombre, $estudiante_grupo, 
                          $descripcion_falta, $tipo_falta, $sancion_aplicada, 
                          $observaciones, $docente_nombre, $record_id]);
            echo json_encode(['success' => true, 'record_id' => $record_id, 'message' => 'Registro actualizado exitosamente']);
        } else {
            // Crear nuevo registro
            $stmt = $pdo->prepare("INSERT INTO registro_disciplinario 
                (fecha_registro, estudiante_nombre, estudiante_grupo, descripcion_falta, 
                 tipo_falta, sancion_aplicada, observaciones, docente_nombre) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$fecha, $estudiante_nombre, $estudiante_grupo, 
                          $descripcion_falta, $tipo_falta, $sancion_aplicada, 
                          $observaciones, $docente_nombre]);
            $new_id = $pdo->lastInsertId();
            echo json_encode(['success' => true, 'record_id' => $new_id, 'message' => 'Registro creado exitosamente']);
        }
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error al guardar registro: ' . $e->getMessage()]);
    }
}

function saveSignature($pdo) {
    try {
        $record_id = $_POST['record_id'] ?? '';
        $tipo_firma = $_POST['tipo_firma'] ?? '';
        $firma_data = $_POST['firma_data'] ?? '';

        // Validaciones
        if (empty($record_id) || empty($tipo_firma) || empty($firma_data)) {
            echo json_encode(['success' => false, 'error' => 'Datos incompletos para guardar la firma']);
            return;
        }

        if (!in_array($tipo_firma, ['estudiante', 'docente'])) {
            echo json_encode(['success' => false, 'error' => 'Tipo de firma no válido']);
            return;
        }

        // Verificar que el registro existe
        $stmt = $pdo->prepare("SELECT id FROM registro_disciplinario WHERE id = ?");
        $stmt->execute([$record_id]);
        if (!$stmt->fetch()) {
            echo json_encode(['success' => false, 'error' => 'Registro no encontrado']);
            return;
        }

        // Procesar la imagen de la firma
        if (strpos($firma_data, 'data:image/png;base64,') === 0) {
            $firma_data = str_replace('data:image/png;base64,', '', $firma_data);
        }
        
        $firma_binary = base64_decode($firma_data);
        
        if ($firma_binary === false) {
            echo json_encode(['success' => false, 'error' => 'Error al procesar la imagen de la firma']);
            return;
        }

        // Crear tabla de firmas si no existe
        $pdo->exec("CREATE TABLE IF NOT EXISTS firmas_digitales (
            id INT AUTO_INCREMENT PRIMARY KEY,
            registro_id INT NOT NULL,
            tipo_firma ENUM('estudiante', 'docente') NOT NULL,
            firma_data LONGBLOB NOT NULL,
            fecha_firma TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            usuario_firma VARCHAR(255),
            INDEX idx_registro_id (registro_id),
            INDEX idx_tipo_firma (tipo_firma)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Verificar si ya existe una firma de este tipo para este registro
        $stmt = $pdo->prepare("SELECT id FROM firmas_digitales WHERE registro_id = ? AND tipo_firma = ?");
        $stmt->execute([$record_id, $tipo_firma]);
        $existing = $stmt->fetch();

        if ($existing) {
            // Actualizar firma existente
            $stmt = $pdo->prepare("UPDATE firmas_digitales SET 
                firma_data = ?, fecha_firma = NOW() 
                WHERE registro_id = ? AND tipo_firma = ?");
            $stmt->execute([$firma_binary, $record_id, $tipo_firma]);
            $message = 'Firma actualizada exitosamente';
        } else {
            // Crear nueva firma
            $stmt = $pdo->prepare("INSERT INTO firmas_digitales 
                (registro_id, tipo_firma, firma_data, fecha_firma) 
                VALUES (?, ?, ?, NOW())");
            $stmt->execute([$record_id, $tipo_firma, $firma_binary]);
            $message = 'Firma guardada exitosamente';
        }

        echo json_encode(['success' => true, 'message' => $message]);

    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error al guardar firma: ' . $e->getMessage()]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error inesperado: ' . $e->getMessage()]);
    }
}

function getRecords($pdo) {
    try {
        $search = $_GET['search'] ?? '';
        $grupo = $_GET['grupo'] ?? '';
        $fecha_inicio = $_GET['fecha_inicio'] ?? '';
        $fecha_fin = $_GET['fecha_fin'] ?? '';

        // Primero verificar si las columnas de firma existen
        $stmt = $pdo->query("SHOW COLUMNS FROM registro_disciplinario LIKE 'firma_%'");
        $firma_columns = $stmt->fetchAll();
        $has_firma_columns = count($firma_columns) > 0;

        if ($has_firma_columns) {
            $sql = "SELECT r.*, 
                    COALESCE(r.firma_estudiante, 0) as firma_estudiante,
                    COALESCE(r.firma_docente, 0) as firma_docente
                    FROM registro_disciplinario r WHERE 1=1";
        } else {
            // Consulta alternativa usando EXISTS para verificar firmas en tabla separada
            $sql = "SELECT r.*, 
                    CASE WHEN EXISTS(SELECT 1 FROM firmas_digitales f WHERE f.registro_id = r.id AND f.tipo_firma = 'estudiante') THEN 1 ELSE 0 END as firma_estudiante,
                    CASE WHEN EXISTS(SELECT 1 FROM firmas_digitales f WHERE f.registro_id = r.id AND f.tipo_firma = 'docente') THEN 1 ELSE 0 END as firma_docente
                    FROM registro_disciplinario r WHERE 1=1";
        }

        $params = [];

        if ($search) {
            $sql .= " AND (r.estudiante_nombre LIKE ? OR r.descripcion_falta LIKE ? OR r.docente_nombre LIKE ?)";
            $searchParam = "%$search%";
            $params[] = $searchParam;
            $params[] = $searchParam;
            $params[] = $searchParam;
        }

        if ($grupo) {
            $sql .= " AND r.estudiante_grupo = ?";
            $params[] = $grupo;
        }

        if ($fecha_inicio) {
            $sql .= " AND r.fecha_registro >= ?";
            $params[] = $fecha_inicio;
        }

        if ($fecha_fin) {
            $sql .= " AND r.fecha_registro <= ?";
            $params[] = $fecha_fin;
        }

        $sql .= " ORDER BY r.fecha_registro DESC, r.id DESC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $records = $stmt->fetchAll();

        echo json_encode(['success' => true, 'records' => $records]);
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error al obtener registros: ' . $e->getMessage()]);
    }
}

function getRecordData($pdo) {
    try {
        $record_id = $_GET['record_id'] ?? '';
        
        if (empty($record_id)) {
            echo json_encode(['success' => false, 'error' => 'ID de registro requerido']);
            return;
        }

        $stmt = $pdo->prepare("SELECT * FROM registro_disciplinario WHERE id = ?");
        $stmt->execute([$record_id]);
        $record = $stmt->fetch();

        if ($record) {
            echo json_encode(['success' => true, 'record' => $record]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Registro no encontrado']);
        }
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error al obtener registro: ' . $e->getMessage()]);
    }
}

function deleteRecord($pdo) {
    try {
        $record_id = $_POST['record_id'] ?? '';

        if (empty($record_id)) {
            echo json_encode(['success' => false, 'error' => 'ID de registro requerido']);
            return;
        }

        // Primero eliminar las firmas asociadas si la tabla existe
        try {
            $stmt = $pdo->prepare("DELETE FROM firmas_digitales WHERE registro_id = ?");
            $stmt->execute([$record_id]);
        } catch(PDOException $e) {
            // Ignorar error si la tabla no existe
        }

        // Luego eliminar el registro
        $stmt = $pdo->prepare("DELETE FROM registro_disciplinario WHERE id = ?");
        $stmt->execute([$record_id]);
        
        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Registro eliminado exitosamente']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Registro no encontrado']);
        }
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error al eliminar: ' . $e->getMessage()]);
    }
}

function getSignature($pdo) {
    try {
        $record_id = $_GET['record_id'] ?? '';
        $tipo_firma = $_GET['tipo_firma'] ?? '';

        if (empty($record_id) || empty($tipo_firma)) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Datos incompletos']);
            return;
        }

        $stmt = $pdo->prepare("SELECT firma_data FROM firmas_digitales WHERE registro_id = ? AND tipo_firma = ?");
        $stmt->execute([$record_id, $tipo_firma]);
        $firma = $stmt->fetch();

        if ($firma && $firma['firma_data']) {
            header('Content-Type: image/png');
            echo $firma['firma_data'];
        } else {
            header('Content-Type: application/json');
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Firma no encontrada']);
        }
    } catch(PDOException $e) {
        header('Content-Type: application/json');
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error al obtener firma: ' . $e->getMessage()]);
    }
}
?>
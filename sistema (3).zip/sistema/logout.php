<?php
session_start(); // Reactivar la sesión para poder destruirla

// Evitar que el navegador almacene páginas en caché
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Eliminar variables y destruir la sesión
session_unset();
session_destroy();

// 🔹 Eliminar cookie de sesión en el navegador
setcookie(session_name(), '', time() - 3600, '/');

// Redirigir al login
header("Location: index.php");
exit();

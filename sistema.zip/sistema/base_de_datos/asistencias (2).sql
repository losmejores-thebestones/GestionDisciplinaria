-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-08-2025 a las 21:23:58
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistema_disciplinario`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asistencias`
--

CREATE TABLE `asistencias` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `grupo` varchar(10) NOT NULL,
  `enero` text DEFAULT NULL,
  `febrero` text DEFAULT NULL,
  `marzo` text DEFAULT NULL,
  `abril` text DEFAULT NULL,
  `mayo` text DEFAULT NULL,
  `junio` text DEFAULT NULL,
  `julio` text DEFAULT NULL,
  `agosto` text DEFAULT NULL,
  `septiembre` text DEFAULT NULL,
  `octubre` text DEFAULT NULL,
  `noviembre` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `asistencias`
--

INSERT INTO `asistencias` (`id`, `nombre`, `grupo`, `enero`, `febrero`, `marzo`, `abril`, `mayo`, `junio`, `julio`, `agosto`, `septiembre`, `octubre`, `noviembre`) VALUES
(1, 'María López Sánchez', '11-2', 'X,X', 'X', '', 'X,X,X', '', '', 'X', '', 'X,X', 'X', 'X'),
(2, 'Carlos Martínez Ríos', '11-2', '', '', 'X,X', '', '', '', '', 'X', '', '', ''),
(3, 'Valentina Ruiz Gómez', '11-2', 'X', 'X,X,X', '', '', 'X', 'X', '', '', 'X', 'X,X,X', ''),
(4, 'Santiago Torres Vega', '11-2', '', '', '', '', '', '', '', '', '', '', ''),
(5, 'Laura Fernández Díaz', '11-2', 'X,X', '', 'X', '', '', 'X,X,X', '', '', '', 'X,X', 'X'),
(6, 'Mateo Herrera Díaz', '0-1', '', '', '', '', '', '', '', '', '', '', ''),
(7, 'Isabella Ríos Torres', '0-2', 'X,X,X,X,X', '', '', '', '', '', '', '', '', '', ''),
(8, 'Samuel Gómez Ramírez', '0-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'Sofía Martínez Ruiz', '1-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 'Lucas Fernández Pérez', '1-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 'Emma Vargas Sánchez', '1-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, 'Diego Castro Morales', '2-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 'Valentina Romero López', '2-2', 'X', '', '', '', '', '', '', '', '', '', ''),
(14, 'Martín Ortega Ríos', '2-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 'Camila Jiménez Herrera', '3-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 'Tomás Soto Torres', '3-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 'Sara Muñoz Díaz', '3-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 'Benjamín Delgado León', '4-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 'Julieta Silva Ramos', '4-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, 'Emilio Vargas Mendoza', '4-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, 'Mía Torres Acosta', '5-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(22, 'Joaquín Rivas Romero', '5-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(23, 'Antonella Martínez Gómez', '5-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(24, 'Gael Ruiz Peña', '6-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(25, 'Renata Castro Jiménez', '6-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(26, 'Thiago Ramírez Herrera', '6-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(27, 'Catalina Sánchez López', '7-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(28, 'Maximiliano Vega Ríos', '7-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(29, 'Abigail Moreno Díaz', '7-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(30, 'Damián Morales García', '8-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(31, 'Regina Méndez Pérez', '8-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(32, 'Andrés González Vargas', '8-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(33, 'Paulina Herrera Rojas', '9-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(34, 'Facundo Romero Mendoza', '9-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(35, 'Elena Rodríguez Silva', '9-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(36, 'Juan Pablo Cruz Torres', '10-1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(37, 'Aitana Gómez Ramírez', '10-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(38, 'Leonardo Ríos Herrera', '10-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(39, 'María López Sánchez', '11-1', 'X,X', 'X', '', 'X,X,X', '', '', 'X', '', 'X,X', 'X', 'X'),
(40, 'Carlos Martínez Ríos', '11-2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(41, 'Valentina Ruiz Gómez', '11-3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(42, 'Isabela Rivera Montoya', '0-4', '', '', '', '', '', '', '', '', '', '', ''),
(43, 'Samuel Castaño Pineda', '6-4', '', '', '', '', '', '', '', '', '', '', ''),
(44, 'Valeria Gómez Ríos', '0-1', '', '', '', '', '', '', '', '', '', '', ''),
(45, 'Tomás López García', '0-2', '', '', '', '', '', '', '', '', '', '', ''),
(46, 'Luciana Mejía Torres', '0-3', '', '', '', '', '', '', '', '', '', '', ''),
(47, 'Isabela Rivera Montoya', '0-4', '', '', '', '', '', '', '', '', '', '', ''),
(48, 'Jerónimo Ortiz Ramírez', '1-1', '', '', '', '', '', '', '', '', '', '', ''),
(49, 'Camila Restrepo Salas', '1-2', '', '', '', '', '', '', '', '', '', '', ''),
(50, 'Samuel Pérez Londoño', '1-3', '', '', '', '', '', '', '', '', '', '', ''),
(51, 'Sara Giraldo Vargas', '2-1', '', '', '', '', '', '', '', '', '', '', ''),
(52, 'Matías Torres Arenas', '2-2', '', '', '', '', '', '', '', '', '', '', ''),
(53, 'Emilia Salazar León', '2-3', '', '', '', '', '', '', '', '', '', '', ''),
(54, 'Juan Pablo Cano', '3-1', '', '', '', '', '', '', '', '', '', '', ''),
(55, 'Antonia Hoyos Jaramillo', '3-2', '', '', '', '', '', '', '', '', '', '', ''),
(56, 'Felipe Marín Álvarez', '3-3', '', '', '', '', '', '', '', '', '', '', ''),
(57, 'Julieta Franco Zuluaga', '4-1', '', '', '', '', '', '', '', '', '', '', ''),
(58, 'Simón Ríos Estrada', '4-2', '', '', '', '', '', '', '', '', '', '', ''),
(59, 'Renata Pineda López', '4-3', '', '', '', '', '', '', '', '', '', '', ''),
(60, 'Emiliano Montoya Díaz', '5-1', '', '', '', '', '', '', '', '', '', '', ''),
(61, 'Mía Herrera Vélez', '5-2', '', '', '', '', '', '', '', '', '', '', ''),
(62, 'David Castro Gómez', '5-3', '', '', '', '', '', '', '', '', '', '', ''),
(63, 'Valentina Londoño Mejía', '6-1', '', '', '', '', '', '', '', '', '', '', ''),
(64, 'Santiago Ramírez Peña', '6-2', '', '', '', '', '', '', '', '', '', '', ''),
(65, 'Isabel Zapata Correa', '6-3', '', '', '', '', '', '', '', '', '', '', ''),
(66, 'Samuel Castaño Pineda', '6-4', '', '', '', '', '', '', '', '', '', '', ''),
(67, 'Nicole Álvarez Rivas', '7-1', '', '', '', '', '', '', '', '', '', '', ''),
(68, 'Juan Diego Benítez Hoyos', '7-2', '', '', '', '', '', '', '', '', '', '', ''),
(69, 'Adriana Palacio Marulanda', '7-3', '', '', '', '', '', '', '', '', '', '', ''),
(70, 'Pedro Salinas Tobón', '8-1', '', '', '', '', '', '', '', '', '', '', ''),
(71, 'Laura Ramírez Giraldo', '8-2', '', '', '', '', '', '', '', '', '', '', ''),
(72, 'Andrés Cardona López', '8-3', '', '', '', '', '', '', '', '', '', '', ''),
(73, 'Mariana Cano Estrada', '9-1', '', '', '', '', '', '', '', '', '', '', ''),
(74, 'Iván Morales Gutiérrez', '9-2', '', '', '', '', '', '', '', '', '', '', ''),
(75, 'Danna Herrera Quintero', '9-3', '', '', '', '', '', '', '', '', '', '', ''),
(76, 'Tomás Suárez Torres', '10-1', '', '', '', '', '', '', '', '', '', '', ''),
(77, 'Michelle Vargas Roldán', '10-2', '', '', '', '', '', '', '', '', '', '', ''),
(78, 'Manuel Ocampo Rivas', '10-3', '', '', '', '', '', '', '', '', '', '', ''),
(79, 'Daniela Lozano Zuluaga', '11-1', '', '', '', '', '', '', '', '', '', '', ''),
(80, 'Esteban Arango Pérez', '11-2', '', '', '', '', '', '', '', '', '', '', ''),
(81, 'María López Sánchez', '11-3', 'X,X', 'X', '', 'X,X,X', '', '', 'X', '', 'X,X', 'X', 'X');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `asistencias`
--
ALTER TABLE `asistencias`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `asistencias`
--
ALTER TABLE `asistencias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

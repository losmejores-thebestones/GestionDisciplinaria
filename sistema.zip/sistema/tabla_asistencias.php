<?php
include 'conexion.php';
?>

<!-- Formulario de búsqueda y selección de grupo -->
<div style="display: flex; justify-content: center; gap: 10px; margin-bottom: 1rem; flex-wrap: wrap;">
  <input type="text" id="buscador" placeholder="Buscar por nombre" style="padding: 8px; width: 280px; border-radius: 5px;">

  <?php
$grupoSeleccionado = $_GET['grupo'] ?? '';
?>

  <select id="filtro-grupo" style="padding: 8px; width: 150px; border-radius: 5px;">
  <option value="" <?= $grupoSeleccionado === '' ? 'selected' : '' ?>>Todos los grupos</option>
  <option value="0-1" <?= $grupoSeleccionado === '0-1' ? 'selected' : '' ?>>0-1</option>
  <option value="0-2" <?= $grupoSeleccionado === '0-2' ? 'selected' : '' ?>>0-2</option>
  <option value="0-3" <?= $grupoSeleccionado === '0-3' ? 'selected' : '' ?>>0-3</option>
  <option value="0-4" <?= $grupoSeleccionado === '0-4' ? 'selected' : '' ?>>0-4</option>
  <option value="1-1" <?= $grupoSeleccionado === '1-1' ? 'selected' : '' ?>>1-1</option>
  <option value="1-2" <?= $grupoSeleccionado === '1-2' ? 'selected' : '' ?>>1-2</option>
  <option value="1-3" <?= $grupoSeleccionado === '1-3' ? 'selected' : '' ?>>1-3</option>
  <option value="2-1" <?= $grupoSeleccionado === '2-1' ? 'selected' : '' ?>>2-1</option>
  <option value="2-2" <?= $grupoSeleccionado === '2-2' ? 'selected' : '' ?>>2-2</option>
  <option value="2-3" <?= $grupoSeleccionado === '2-3' ? 'selected' : '' ?>>2-3</option>
  <option value="3-1" <?= $grupoSeleccionado === '3-1' ? 'selected' : '' ?>>3-1</option>
  <option value="3-2" <?= $grupoSeleccionado === '3-2' ? 'selected' : '' ?>>3-2</option>
  <option value="3-3" <?= $grupoSeleccionado === '3-3' ? 'selected' : '' ?>>3-3</option>
  <option value="4-1" <?= $grupoSeleccionado === '4-1' ? 'selected' : '' ?>>4-1</option>
  <option value="4-2" <?= $grupoSeleccionado === '4-2' ? 'selected' : '' ?>>4-2</option>
  <option value="4-3" <?= $grupoSeleccionado === '4-3' ? 'selected' : '' ?>>4-3</option>
  <option value="5-1" <?= $grupoSeleccionado === '5-1' ? 'selected' : '' ?>>5-1</option>
  <option value="5-2" <?= $grupoSeleccionado === '5-2' ? 'selected' : '' ?>>5-2</option>
  <option value="5-3" <?= $grupoSeleccionado === '5-3' ? 'selected' : '' ?>>5-3</option>
  <option value="6-1" <?= $grupoSeleccionado === '6-1' ? 'selected' : '' ?>>6-1</option>
  <option value="6-2" <?= $grupoSeleccionado === '6-2' ? 'selected' : '' ?>>6-2</option>
  <option value="6-3" <?= $grupoSeleccionado === '6-3' ? 'selected' : '' ?>>6-3</option>
  <option value="6-4" <?= $grupoSeleccionado === '6-4' ? 'selected' : '' ?>>6-4</option>
  <option value="7-1" <?= $grupoSeleccionado === '7-1' ? 'selected' : '' ?>>7-1</option>
  <option value="7-2" <?= $grupoSeleccionado === '7-2' ? 'selected' : '' ?>>7-2</option>
  <option value="7-3" <?= $grupoSeleccionado === '7-3' ? 'selected' : '' ?>>7-3</option>
  <option value="8-1" <?= $grupoSeleccionado === '8-1' ? 'selected' : '' ?>>8-1</option>
  <option value="8-2" <?= $grupoSeleccionado === '8-2' ? 'selected' : '' ?>>8-2</option>
  <option value="8-3" <?= $grupoSeleccionado === '8-3' ? 'selected' : '' ?>>8-3</option>
  <option value="9-1" <?= $grupoSeleccionado === '9-1' ? 'selected' : '' ?>>9-1</option>
  <option value="9-2" <?= $grupoSeleccionado === '9-2' ? 'selected' : '' ?>>9-2</option>
  <option value="9-3" <?= $grupoSeleccionado === '9-3' ? 'selected' : '' ?>>9-3</option>
  <option value="10-1" <?= $grupoSeleccionado === '10-1' ? 'selected' : '' ?>>10-1</option>
  <option value="10-2" <?= $grupoSeleccionado === '10-2' ? 'selected' : '' ?>>10-2</option>
  <option value="10-3" <?= $grupoSeleccionado === '10-3' ? 'selected' : '' ?>>10-3</option>
  <option value="11-1" <?= $grupoSeleccionado === '11-1' ? 'selected' : '' ?>>11-1</option>
  <option value="11-2" <?= $grupoSeleccionado === '11-2' ? 'selected' : '' ?>>11-2</option>
  <option value="11-3" <?= $grupoSeleccionado === '11-3' ? 'selected' : '' ?>>11-3</option>
</select>
</div>

<!-- Tabla con cuerpo dinámico -->
<div class="tabla-container">
  <table class="tabla-asistencia">
    <thead>
      <tr>
        <th>Nombre</th>
        <th>Acción</th>
        <th>Grupo</th>
        <th>Calendario</th>
      </tr>
    </thead>
    <tbody id="cuerpo-tabla">
      <?php include 'buscar_asistencias.php'; ?>
    </tbody>
  </table>
</div>

<script>
// Espera a que todo el documento HTML termine de cargarse
document.addEventListener('DOMContentLoaded', () => {

  // Selecciona todos los botones que tienen la clase .guardar-cambios
  document.querySelectorAll('.guardar-cambios').forEach(boton => {

    // Agrega un evento click a cada botón
    boton.addEventListener('click', async (event) => {

      event.preventDefault(); // 👈 evita que el botón recargue la página o la tabla

      // Obtiene el id del estudiante desde el atributo data-id del botón
      const id = boton.dataset.id;

      // Busca la fila (tr) que contiene el botón
      const fila = boton.closest('tr');

      // Dentro de esa fila busca el input de tipo fecha
      const fechaInput = fila.querySelector('.selector-fecha');

      // Obtiene el valor de la fecha seleccionada (formato YYYY-MM-DD)
      const fecha = fechaInput ? fechaInput.value : '';

      // Si no hay fecha seleccionada, muestra un aviso y no guarda nada
      if (!fecha) {
        alert('Por favor selecciona una fecha antes de guardar.');
        return;
      }

      // Prepara los datos que se enviarán al servidor
      const datos = new URLSearchParams();
      datos.append('id', id);      // id del estudiante
      datos.append('fecha', fecha); // fecha seleccionada

      try {
        // Desactiva el botón para evitar múltiples clics mientras se guarda
        boton.disabled = true;

        // Envía la petición al servidor (guardar_asistencia.php)
        const resp = await fetch('guardar_asistencia.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: datos.toString()
        });

        // Obtiene el texto de respuesta del servidor
        const text = await resp.text();

        // Si todo salió bien y el servidor respondió "OK"
        if (resp.ok && text.trim() === 'OK') {
          boton.innerHTML = '<i class="fas fa-check-circle"></i> Guardado';
          boton.classList.add('guardado');
        } else {
          alert('Error al guardar: ' + text);
        }

      } catch (err) {
        alert('Error de red o servidor: ' + err.message);

      } finally {
        // Después de 2 segundos, restauramos el botón a su estado original
        setTimeout(() => {
          boton.disabled = false;
          boton.innerHTML = '<i class="fas fa-save"></i> Guardar';
          boton.classList.remove('guardado');
        }, 2000);
      }
    });
  });
});

// Cargar tabla con filtros actuales
function cargarTabla() {
  const nombre = document.getElementById('buscador').value;
  const grupo = document.getElementById('filtro-grupo').value;
  const url = `../buscar_asistencias.php?buscar=${encodeURIComponent(nombre)}&grupo=${encodeURIComponent(grupo)}`;

  fetch(url)
    .then(res => res.text())
    .then(html => {
      document.getElementById('cuerpo-tabla').innerHTML = html;
      activarEventos(); // REACTIVA los eventos en los nuevos elementos
    });
}

// Eventos del buscador y selector
document.getElementById('buscador').addEventListener('keyup', cargarTabla);
document.getElementById('filtro-grupo').addEventListener('change', cargarTabla);

// Eventos iniciales
document.addEventListener('DOMContentLoaded', () => {
  activarEventos(); // Activar al cargar la página
});
</script>


<?php $conn->close(); ?>

<?php
session_start();

// 🔒 Evitar caché
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// 🔑 Verificar sesión
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}

// 🕒 Tiempo máximo de inactividad (ejemplo: 5 minutos)
$inactividad = 300; // 300 segundos = 5 min

if (!isset($_SESSION['tiempo'])) {
    $_SESSION['tiempo'] = time();
} elseif (time() - $_SESSION['tiempo'] > $inactividad) {
    // Se excedió el tiempo → cerrar sesión
    session_unset();
    session_destroy();
    setcookie(session_name(), '', time() - 3600, '/');
    header("Location: index.php?timeout=1");
    exit();
}

// Actualizar tiempo de última actividad
$_SESSION['tiempo'] = time();
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Registro de llegadas tarde | I.E. Santa Teresa</title>
  <link rel="icon" href="img/logosantaie.gif" type="image/x-icon" />
  <link rel="stylesheet" href="estilos.css">

  <!-- Bootstrap + Font Awesome -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />

  <style>
    body {
      font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
      background: transparent;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    /* Slider de fondo fijo */
    .hero-slider {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100vh;
      z-index: -1;
    }

    .slider-container {
      position: relative;
      width: 100%;
      height: 100%;
    }

    .slide {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      opacity: 0;
      transition: opacity 1s ease-in-out;
    }

    .slide.active {
      opacity: 1;
    }

    .slide img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .slide-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(
        45deg,
        rgba(44, 90, 160, 0.7) 0%,
        rgba(74, 144, 226, 0.5) 50%,
        rgba(0, 212, 255, 0.3) 100%
      );
    }

    /* Header en la parte superior */
    header {
      background: transparent !important;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      padding: 20px;
      max-width: 1000px;
      margin: 0 auto;
      backdrop-filter: none !important;
      border-radius: 15px;
      box-shadow: none !important;
      position: relative;
      z-index: 1000;
      margin-top: 20px;
    }

    header img.logo {
      width: 150px;
    }

  header h1 {
      flex-grow: 1;
      text-align: center;
      color: white;
      font-weight: 650;
      font-size: 321%;
      letter-spacing: 2px;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      text-transform: none !important;
    }


    /* Main content - contenedor principal */
    main {
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      align-items: center;
      position: relative;
      z-index: 200;
      padding: 60px 20px 50px;
      min-height: calc(100vh - 300px);
    }

    /* Contenedor del dropdown centrado */
    .selector-container {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      margin-top: 60px;
      position: relative;
      z-index: 9999;
      margin-bottom: 80px;
      margin-top: -2%;
    }

    .dropdown {
      position: relative;
      z-index: 10000;
    }

    .dropdown-toggle {
      background-color: white;
      color: #2699C7;
      border: 2px solid #2699C7;
      font-weight: bold;
      transition: all 0.3s ease;
      min-width: 300px;
      padding: 15px 25px;
      font-size: 1.2rem;
      border-radius: 10px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      position: relative;
      z-index: 10001;
    }

    .dropdown-toggle:hover,
    .dropdown-toggle:focus {
      background-color: #007bff;
      color: white;
      box-shadow: 0 6px 20px rgba(0, 123, 255, 0.3);
      transform: translateY(-2px);
    }

    .dropdown-menu {
      max-height: 300px;
      overflow-y: auto;
      min-width: 300px;
      border: none;
      box-shadow: 0 8px 25px rgba(0,0,0,0.15);
      border-radius: 10px;
      position: absolute !important;
      z-index: 10002 !important;
      background: white !important;
      top: calc(100% + 8px) !important;
      bottom: auto !important;
      transform: none !important;
      left: 0 !important;
      right: auto !important;
      /* Asegurar que el dropdown esté por encima de todo */
      will-change: transform;
      inset: unset !important;
    }

    .dropdown-menu.show {
      display: block !important;
      z-index: 10002 !important;
      position: absolute !important;
    }

    .dropdown-item {
      padding: 12px 20px;
      transition: all 0.2s ease;
      background: white;
      color: #333;
      border: none;
    }

    .dropdown-item:hover {
      background-color: #f8f9fa;
      color: #2699C7;
      transform: translateX(5px);
    }

    /* Footer que no interfiera con el contenido */
    footer.modern-footer {
      background: rgba(52, 58, 64, 0.95);
      backdrop-filter: blur(15px);
      position: relative;
      z-index: 10;
      margin-top: auto;
    }

    .footer-content {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 2rem;
    }

    .footer-brand {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .footer-logo {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      object-fit: cover;
    }

    .footer-info h3 {
      font-size: 1.3rem;
      margin-bottom: 0.5rem;
      color: white;
    }

    .footer-info p {
      color: #ccc;
      font-size: 0.9rem;
      margin: 0;
    }

    .footer-links {
      display: flex;
      gap: 2rem;
    }

    .footer-link {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      color: white;
      text-decoration: none;
      transition: all 0.3s ease;
    }

    .footer-link:hover {
      color: #00d4ff;
      transform: translateY(-2px);
    }

    .footer-bottom {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      padding: 1.5rem 2rem;
      text-align: center;
      color: #ccc;
      font-size: 0.9rem;
      max-width: 1200px;
      margin: 0 auto;
    }

    /* Agregar clase para forzar dropdown hacia abajo */
    .dropdown.force-down .dropdown-menu {
      top: calc(100% + 8px) !important;
      bottom: auto !important;
      transform: none !important;
      inset: unset !important;
    }

    /* Scrollbar personalizado para el dropdown */
    .dropdown-menu::-webkit-scrollbar {
      width: 8px;
    }

    .dropdown-menu::-webkit-scrollbar-track {
      background: #f1f1f1;
      border-radius: 10px;
    }

    .dropdown-menu::-webkit-scrollbar-thumb {
      background: #2699C7;
      border-radius: 10px;
    }

    .dropdown-menu::-webkit-scrollbar-thumb:hover {
      background: #007bff;
    }

    /* Responsive */
    @media (max-width: 768px) {
      header {
        flex-direction: column;
        text-align: center;
        gap: 15px;
        margin: 10px;
        padding: 15px;
      }

      header h1 {
        font-size: 1.8rem;
      }

      header img.logo {
        width: 120px;
      }

      .selector-container {
        margin-top: 30px;
        z-index: 9999;
        margin-bottom: 60px;
      }

      .dropdown {
        z-index: 10000;
      }

      .dropdown-toggle {
        min-width: 280px;
        font-size: 1.1rem;
        padding: 12px 20px;
        z-index: 10001;
      }

      .dropdown-menu {
        min-width: 280px;
        z-index: 10002 !important;
        max-height: 250px;
      }

      .footer-content {
        flex-direction: column;
        text-align: center;
        padding: 1.5rem;
      }

      .footer-links {
        flex-direction: column;
        gap: 1rem;
      }

      main {
        padding: 40px 15px 30px;
      }
    }

    @media (max-width: 480px) {
      header {
        margin: 5px;
        padding: 10px;
      }

      header h1 {
        font-size: 1.4rem;
      }

      header img.logo {
        width: 100px;
      }

      .dropdown-toggle {
        min-width: 250px;
        font-size: 1rem;
        padding: 10px 15px;
        z-index: 10001;
      }

      .dropdown-menu {
        min-width: 250px;
        z-index: 10002 !important;
        max-height: 200px;
      }

      main {
        padding: 30px 10px 20px;
      }

      .selector-container {
        margin-top: 40px;
        z-index: 9999;
        margin-bottom: 40px;
      }
    }
  </style>
</head>
<body>

  <!-- Slider de fondo -->
  <section class="hero-slider">
    <div class="slider-container">
      <div class="slide active">
        <img src="img/s1.jpeg" alt="Instalaciones educativas">
        <div class="slide-overlay"></div>
      </div>
      <div class="slide">
        <img src="img/s2.jpeg" alt="Estudiantes en actividades">
        <div class="slide-overlay"></div>
      </div>
      <div class="slide">
        <img src="img/s3.jpeg" alt="Aulas modernas">
        <div class="slide-overlay"></div>
      </div>
      <div class="slide">
        <img src="img/s4.jpeg" alt="Espacios deportivos">
        <div class="slide-overlay"></div>
      </div>
      <div class="slide">
        <img src="img/fondo.jpeg" alt="Campus institucional">
        <div class="slide-overlay"></div>
      </div>
    </div>
  </section>

  <!-- Header -->
  <header>
    <a href="menu.php">
      <img src="img/logosantaie.gif" class="logo" alt="Logo" />
    </a>
    <h1>Registro De Llegadas Tarde</h1>
  </header>

  <!-- Contenido principal -->
  <main>
    <div class="selector-container">
      <div class="dropdown force-down">
        <button class="btn dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="true">
          Selecciona un grupo
        </button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=0-1">0-1</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=0-2">0-2</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=0-3">0-3</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=0-4">0-4</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=1-1">1-1</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=1-2">1-2</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=1-3">1-3</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=2-1">2-1</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=2-2">2-2</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=2-3">2-3</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=3-1">3-1</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=3-2">3-2</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=3-3">3-3</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=4-1">4-1</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=4-2">4-2</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=4-3">4-3</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=5-1">5-1</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=5-2">5-2</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=5-3">5-3</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=6-1">6-1</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=6-2">6-2</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=6-3">6-3</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=6-4">6-4</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=7-1">7-1</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=7-2">7-2</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=7-3">7-3</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=8-1">8-1</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=8-2">8-2</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=8-3">8-3</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=9-1">9-1</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=9-2">9-2</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=9-3">9-3</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=10-2">10-1</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=10-2">10-2</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=10-3">10-3</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=11-2">11-1</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=11-2">11-2</a></li>
  <li><a class="dropdown-item" href="/sistema/Grupos/registro.php?grupo=11-3">11-3</a></li>
</ul>

      </div>
    </div>
  </main>

  <!-- Footer -->
  <footer class="modern-footer">
    <div class="footer-content">
      <div class="footer-brand">
        <img src="img/logosantaie.gif" alt="Logo" class="footer-logo" />
        <div class="footer-info">
          <h3>Institución Educativa Santa Teresa</h3>
          <p>Sistema de Gestión Disciplinaria</p>
        </div>
      </div>
      <div class="footer-links">
        <a href="https://santateresaie.edu.co/wp-content/uploads/2025/04/POLITICA-DE-PROTECCION-DE-DATOS.pdf" class="footer-link"><i class="fas fa-shield-alt"></i> Política de Privacidad</a>
        <a href="#" class="footer-link"><i class="fas fa-envelope"></i> Contacto | piagestiondisciplinaria1@gmail.com</a>
      </div>
    </div>
    <div class="footer-bottom">
      <p>&copy; 2025 Institución Educativa Santa Teresa. Todos los derechos reservados.</p>
    </div>
  </footer>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

  <script>
    const slides = document.querySelectorAll('.slide');
    let currentSlide = 0;

    function showSlide(index) {
      slides.forEach((slide, i) => {
        slide.classList.toggle('active', i === index);
      });
    }

    function nextSlide() {
      currentSlide = (currentSlide + 1) % slides.length;
      showSlide(currentSlide);
    }

    // Iniciar el slider
    showSlide(0);
    setInterval(nextSlide, 5000);

    // Mejorar el comportamiento del dropdown
    document.addEventListener('DOMContentLoaded', function() {
      const dropdownToggle = document.getElementById('dropdownMenuButton');
      const dropdownMenu = document.querySelector('.dropdown-menu');
      
      // Forzar que el dropdown se abra hacia abajo
      function forceDropdownDown() {
        dropdownMenu.style.position = 'absolute';
        dropdownMenu.style.zIndex = '10002';
        dropdownMenu.style.top = 'calc(100% + 8px)';
        dropdownMenu.style.bottom = 'auto';
        dropdownMenu.style.left = '0';
        dropdownMenu.style.right = 'auto';
        dropdownMenu.style.transform = 'none';
        dropdownMenu.style.inset = 'unset';
      }

      // Aplicar cuando se muestra el dropdown
      dropdownToggle.addEventListener('shown.bs.dropdown', function() {
        forceDropdownDown();
      });

      // También manejar el evento de click
      dropdownToggle.addEventListener('click', function() {
        setTimeout(() => {
          if (dropdownMenu.classList.contains('show')) {
            forceDropdownDown();
          }
        }, 10);
      });

      // Observar cambios en las clases para forzar posicionamiento
      const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
          if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
            if (dropdownMenu.classList.contains('show')) {
              setTimeout(forceDropdownDown, 5);
            }
          }
        });
      });

      observer.observe(dropdownMenu, {
        attributes: true,
        attributeFilter: ['class']
      });
    });
  </script>
</body>
</html>
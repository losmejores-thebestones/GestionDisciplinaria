document.addEventListener('DOMContentLoaded', () => {
    const generateButton = document.getElementById('generateTableButton');
    const removeButton = document.getElementById('removeSelectedTablesButton');
    const container = document.getElementById('tableContainer');

    // Función para crear una tabla
    function createTable() {
        const table = document.createElement('table');
        table.classList.add('auto-height');

        // Crear encabezado de la tabla
        const thead = document.createElement('thead');
        const headerRow = document.createElement('tr');
        const headers = ['Seleccionar', 'Descripción de la amonestación', 'Descargos', 'Firma'];

        headers.forEach(text => {
            const th = document.createElement('th');
            if (text === 'Seleccionar') {
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.classList.add('select-table');
                th.appendChild(checkbox);
            } else {
                th.textContent = text;
            }
            headerRow.appendChild(th);
        });

        thead.appendChild(headerRow);
        table.appendChild(thead);

        // Crear cuerpo de la tabla
        const tbody = document.createElement('tbody');
        const row = document.createElement('tr');

        headers.slice(1).forEach((text) => { // Excluyendo el primer elemento "Seleccionar"
            const td = document.createElement('td');
            const textarea = document.createElement('textarea');
            textarea.classList.add('editable');
            textarea.addEventListener('input', adjustHeight);
            td.appendChild(textarea);
            row.appendChild(td);
        });

        tbody.appendChild(row);
        table.appendChild(tbody);

        // Añadir la tabla al contenedor
        container.appendChild(table);
    }

    // Función para ajustar la altura del textarea
    function adjustHeight(event) {
        const textarea = event.target;
        textarea.style.height = 'auto';
        textarea.style.height = textarea.scrollHeight + 'px';
    }

    // Función para eliminar las tablas seleccionadas
    function removeSelectedTables() {
        const tables = container.getElementsByTagName('table');
        for (let i = tables.length - 1; i >= 0; i--) {
            const table = tables[i];
            const checkbox = table.querySelector('.select-table');
            if (checkbox && checkbox.checked) {
                container.removeChild(table);
            }
        }
    }

    // Event listeners
    generateButton.addEventListener('click', createTable);
    removeButton.addEventListener('click', removeSelectedTables);
});
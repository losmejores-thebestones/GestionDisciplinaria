<?php // Inicio del código PHP

include 'conexion.php'; 
// Incluye el archivo 'conexion.php', que contiene la conexión a la base de datos
// y define la variable $conn para interactuar con MySQL.

// Obtiene el valor del campo 'nombre' enviado por POST, si no existe se asigna cadena vacía.
$nombre = $_POST['nombre'] ?? ''; 

// Array con los nombres de los meses (sin 'diciembre', probablemente a propósito)
$meses = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre'];

// Array que almacenará las partes del SET en la sentencia UPDATE
$updates = [];

// Recorre todos los meses definidos en el array
foreach ($meses as $mes) {
  // Si el mes actual está presente en el formulario enviado (POST)
  if (isset($_POST[$mes])) {
    // Escapa el valor para evitar inyecciones SQL
    $valor = $conn->real_escape_string($_POST[$mes]);
    // Añade una cadena del tipo "mes = 'valor'" al array $updates
    $updates[] = "$mes = '$valor'";
  }
}

// Si se ha proporcionado un nombre y hay campos para actualizar
if (!empty($nombre) && !empty($updates)) {
  // Construye la consulta SQL UPDATE usando implode para unir las partes con coma
  $sql = "UPDATE asistencias SET " . implode(', ', $updates) . " WHERE nombre = '$nombre'";
  
  // Ejecuta la consulta y verifica si fue exitosa
  if ($conn->query($sql)) {
    echo "Actualizado correctamente"; // Mensaje si todo salió bien
  } else {
    echo "Error al actualizar: " . $conn->error; // Muestra el error si falla
  }
} else {
  // Si falta el nombre o no se envió ningún mes para actualizar
  echo "Faltan datos";
}

// Cierra la conexión con la base de datos
$conn->close();

?> 

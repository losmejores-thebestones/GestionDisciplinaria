<?php
include 'conexion.php';

// Construcción segura de condiciones
$condiciones = [];

// Filtrar por nombre
if (!empty($_GET['buscar'])) {
  $buscar = $conn->real_escape_string($_GET['buscar']);
  $condiciones[] = "(nombre LIKE '%$buscar%' OR grupo LIKE '%$buscar%')";
}

// Filtrar por grupo
if (!empty($_GET['grupo'])) {
  $grupo = $conn->real_escape_string($_GET['grupo']);
  $condiciones[] = "grupo = '$grupo'";
}

// Armar cláusula WHERE si hay condiciones
$where = count($condiciones) > 0 ? 'WHERE ' . implode(' AND ', $condiciones) : '';

// Consulta SQL (solo nombre y grupo)
$sql = "SELECT id, nombre, grupo, fecha FROM asistencias $where";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0):
  while ($row = $result->fetch_assoc()):
?>
  <tr data-id="<?= (int)$row['id'] ?>">
    <td><?= htmlspecialchars($row['nombre']) ?></td>
    <td>
      <button type="button" class="guardar-cambios boton-guardar" data-id="<?= (int)$row['id'] ?>">
        <i class="fas fa-save"></i> Guardar
      </button>
    </td>
    <td><?= htmlspecialchars($row['grupo']) ?></td>
    <td>
      <input type="date" class="selector-fecha" value="<?= htmlspecialchars($row['fecha']) ?>">
    </td>
  </tr>
<?php
  endwhile;
else:
?>
  <tr>
    <td colspan="4" style="text-align: center; padding: 1rem; color: gray;">
      No se encontraron resultados.
    </td>
  </tr>
<?php endif; ?>

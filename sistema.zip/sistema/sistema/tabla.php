<?php
session_start();

// 🔒 Evitar caché
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// 🔒 Verificar sesión
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}

// 🕒 Tiempo máximo de inactividad (ejemplo: 5 minutos)
$inactividad = 300; // 300 segundos = 5 min

if (!isset($_SESSION['tiempo'])) {
    $_SESSION['tiempo'] = time();
} elseif (time() - $_SESSION['tiempo'] > $inactividad) {
    // Se excedió el tiempo → cerrar sesión
    session_unset();
    session_destroy();
    setcookie(session_name(), '', time() - 3600, '/');
    header("Location: index.php?timeout=1");
    exit();
}

// Actualizar tiempo de última actividad
$_SESSION['tiempo'] = time();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Libro de Disciplina Digital | I.E. Santa Teresa</title>
    <link rel="icon" href="img/logosantaie.gif" type="image/x-icon" />
    <link rel="stylesheet" href="estilos.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />

    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background: transparent;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Slider de imágenes de fondo */
        .hero-slider {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100vh;
            z-index: -1;
        }

        .slider-container {
            width: 100%;
            height: 100%;
            position: relative;
        }

        .slide {
            position: absolute;
            width: 100%;
            height: 100%;
            opacity: 0;
            transition: opacity 1s ease-in-out;
        }

        .slide.active {
            opacity: 1;
        }

        .slide img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .slide-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(
                45deg,
                rgba(44, 90, 160, 0.7) 0%,
                rgba(74, 144, 226, 0.5) 50%,
                rgba(0, 212, 255, 0.3) 100%
            );
        }

        /* Header */
        header {
            margin-top: 30px;
            background: transparent;
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin-inline: auto;
            padding: 10px 20px;
            z-index: 1000;
            position: relative;
        }

        header h1 {
            color: white;
            font-size: 2.5rem;
            font-weight: bold;
            text-align: center;
            flex-grow: 1;
        }

        header img.logo {
            width: 120px;
        }

        /* Main content */
        main {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 30px 20px;
            z-index: 10;
            position: relative;
        }

        /* Controles superiores */
        .controls {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 1200px;
        }

        .controls-row {
            display: flex;
            gap: 15px;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .search-group {
            display: flex;
            gap: 10px;
            align-items: center;
            flex: 1;
            min-width: 200px;
        }

        .btn-add-record {
            background: linear-gradient(45deg, #28a745, #20c997);
            border: none;
            color: white;
            padding: 12px 25px;
            border-radius: 10px;
            font-weight: bold;
            box-shadow: 0 4px 15px rgba(40, 167, 69, 0.3);
            transition: all 0.3s ease;
        }

        .btn-add-record:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(40, 167, 69, 0.4);
        }

        /* Tabla de registros */
        .table-container {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 1200px;
            overflow-x: auto;
        }

        .records-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        .records-table th,
        .records-table td {
            padding: 12px;
            border: 1px solid #dee2e6;
            text-align: left;
            vertical-align: top;
        }

        .records-table th {
            background: linear-gradient(45deg, #007bff, #0056b3);
            color: white;
            font-weight: bold;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .records-table tbody tr:nth-child(even) {
            background-color: #f8f9fa;
        }

        .records-table tbody tr:hover {
            background-color: #e3f2fd;
        }

        /* Botones de firma */
        .signature-btn {
            padding: 6px 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.85rem;
            margin: 2px;
            transition: all 0.3s ease;
            display: inline-block;
            text-decoration: none;
        }

        .signature-btn.signed {
            background: #28a745;
            color: white;
        }

        .signature-btn.unsigned {
            background: #dc3545;
            color: white;
        }

        .signature-btn:hover {
            transform: scale(1.05);
        }

        /* Estilos para las celdas de firma */
        .signature-cell {
            text-align: center;
            min-width: 120px;
        }

        .signature-image {
            display: block;
            max-width: 100px;
            max-height: 50px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin: 5px auto;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .signature-image:hover {
            transform: scale(1.1);
            border-color: #007bff;
            box-shadow: 0 2px 8px rgba(0,123,255,0.3);
        }

        /* Modal de firma */
        .signature-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            z-index: 9999;
            align-items: center;
            justify-content: center;
        }

        .signature-modal.show {
            display: flex;
        }

        .signature-content {
            background: white;
            border-radius: 15px;
            padding: 30px;
            max-width: 600px;
            width: 90%;
            text-align: center;
        }

        .signature-canvas {
            border: 2px solid #007bff;
            border-radius: 10px;
            cursor: crosshair;
            margin: 20px 0;
            touch-action: none;
        }

        .signature-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 20px;
        }

        /* Modal para visualizar firma */
        .signature-view-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            z-index: 10000;
            align-items: center;
            justify-content: center;
        }

        .signature-view-modal.show {
            display: flex;
        }

        .signature-view-content {
            background: white;
            border-radius: 15px;
            padding: 30px;
            max-width: 600px;
            width: 90%;
            text-align: center;
        }

        .signature-view-image {
            max-width: 100%;
            max-height: 300px;
            border: 2px solid #007bff;
            border-radius: 10px;
            margin: 20px 0;
        }

        /* Modal de formulario */
        .form-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            z-index: 9999;
            overflow-y: auto;
        }

        .form-modal.show {
            display: block;
        }

        .form-content {
            background: white;
            border-radius: 15px;
            padding: 30px;
            max-width: 700px;
            width: 90%;
            margin: 50px auto;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 2px solid #dee2e6;
            border-radius: 8px;
            font-size: 14px;
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }

        /* Toast notifications */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 10000;
        }

        .toast-notification {
            background: #28a745;
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            opacity: 0;
            transform: translateX(100%);
            transition: all 0.3s ease;
        }

        .toast-notification.show {
            opacity: 1;
            transform: translateX(0);
        }

        .toast-notification.error {
            background: #dc3545;
        }

        /* Loading spinner */
        .loading {
            display: none;
            text-align: center;
            padding: 20px;
        }

        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #007bff;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Responsive */
        @media (max-width: 768px) {
            header h1 {
                font-size: 1.8rem;
            }
            
            .controls-row {
                flex-direction: column;
                align-items: stretch;
            }
            
            .signature-content {
                width: 95%;
                padding: 20px;
            }
            
            .signature-canvas {
                width: 100%;
            }
        }

        /* Estilos para las celdas de firma */
.signature-cell {
    text-align: center;
    min-width: 120px;
}

.signature-image {
    display: block;
    max-width: 100px;
    max-height: 50px;
    border: 1px solid #ddd;
    border-radius: 4px;
    margin: 5px auto;
    cursor: pointer;
    transition: all 0.3s ease;
}

.signature-image:hover {
    transform: scale(1.1);
    border-color: #007bff;
    box-shadow: 0 2px 8px rgba(0,123,255,0.3);
}

/* Modal para visualizar firma */
.signature-view-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.8);
    z-index: 10000;
    align-items: center;
    justify-content: center;
}

.signature-view-modal.show {
    display: flex;
}

.signature-view-content {
    background: white;
    border-radius: 15px;
    padding: 30px;
    max-width: 600px;
    width: 90%;
    text-align: center;
}

.signature-view-image {
    max-width: 100%;
    max-height: 300px;
    border: 2px solid #007bff;
    border-radius: 10px;
    margin: 20px 0;
}
    </style>
</head>
<body>
    <!-- Slider de fondo -->
    <section class="hero-slider">
        <div class="slider-container">
            <div class="slide active">
                <img src="img/s1.jpeg" alt="Imagen 1">
                <div class="slide-overlay"></div>
            </div>
            <div class="slide">
                <img src="img/s2.jpeg" alt="Imagen 2">
                <div class="slide-overlay"></div>
            </div>
            <div class="slide">
                <img src="img/s3.jpeg" alt="Imagen 3">
                <div class="slide-overlay"></div>
            </div>
            <div class="slide">
                <img src="img/s4.jpeg" alt="Imagen 4">
                <div class="slide-overlay"></div>
            </div>
        </div>
    </section>

    <!-- Header -->
    <header>
        <a href="menu.php">
            <img src="img/logosantaie.gif" class="logo" alt="Logo">
        </a>
        <h1>LIBRO DE DISCIPLINA DIGITAL</h1>
    </header>

    <!-- Main content -->
    <main>
        <!-- Controles -->
        <div class="controls">
            <div class="controls-row">
                <div class="search-group">
                    <input type="text" id="searchInput" class="form-control" placeholder="Buscar por nombre, descripción o docente...">
                    <select id="groupFilter" class="form-select">
                        <option value="">Todos los grupos</option>
                        <option value="0-1">0-1</option>
                        <option value="0-2">0-2</option>
                        <option value="0-3">0-3</option>
                        <option value="0-4">0-4</option>
                        <option value="1-1">1-1</option>
                        <option value="1-2">1-2</option>
                        <option value="1-3">1-3</option>
                        <option value="2-1">2-1</option>
                        <option value="2-2">2-2</option>
                        <option value="2-3">2-3</option>
                        <option value="3-1">3-1</option>
                        <option value="3-2">3-2</option>
                        <option value="3-3">3-3</option>
                        <option value="4-1">4-1</option>
                        <option value="4-2">4-2</option>
                        <option value="4-3">4-3</option>
                        <option value="5-1">5-1</option>
                        <option value="5-2">5-2</option>
                        <option value="5-3">5-3</option>
                        <option value="6-1">6-1</option>
                        <option value="6-2">6-2</option>
                        <option value="6-3">6-3</option>
                        <option value="6-4">6-4</option>
                        <option value="7-1">7-1</option>
                        <option value="7-2">7-2</option>
                        <option value="7-3">7-3</option>
                        <option value="8-1">8-1</option>
                        <option value="8-2">8-2</option>
                        <option value="8-3">8-3</option>
                        <option value="9-1">9-1</option>
                        <option value="9-2">9-2</option>
                        <option value="9-3">9-3</option>
                        <option value="10-1">10-1</option>
                        <option value="10-2">10-2</option>
                        <option value="10-3">10-3</option>
                        <option value="11-1">11-1</option>
                        <option value="11-2">11-2</option>
                        <option value="11-3">11-3</option>
                    </select>
                    <input type="date" id="startDate" class="form-control" title="Fecha inicio">
                    <input type="date" id="endDate" class="form-control" title="Fecha fin">
                </div>
                <button type="button" class="btn btn-add-record" onclick="openRecordModal()">
                    <i class="fas fa-plus"></i> Nuevo Registro
                </button>
            </div>
        </div>

        <!-- Tabla de registros -->
        <div class="table-container">
            <div class="loading" id="loading">
                <div class="spinner"></div>
                <p>Cargando registros...</p>
            </div>
            
            <table class="records-table" id="recordsTable" style="display: none;">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Estudiante</th>
                        <th>Grupo</th>
                        <th>Descripción</th>
                        <th>Tipo de Falta</th>
                        <th>Sanción</th>
                        <th>Docente</th>
                        <th>Firma Estudiante</th>
                        <th>Firma Docente</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody id="recordsTableBody">
                    <!-- Los registros se cargan dinámicamente aquí -->
                </tbody>
            </table>
        </div>
    </main>

    <!-- Footer -->
    <footer class="modern-footer">
        <div class="footer-content">
            <div class="footer-brand">
                <img src="img/logosantaie.gif" alt="Logo" class="footer-logo" />
                <div class="footer-info">
                    <h3>Institución Educativa Santa Teresa</h3>
                    <p>Sistema de Gestión Disciplinaria</p>
                </div>
            </div>
            <div class="footer-links">
                <a href="https://santateresaie.edu.co/wp-content/uploads/2025/04/POLITICA-DE-PROTECCION-DE-DATOS.pdf" class="footer-link">
                    <i class="fas fa-shield-alt"></i> Política de Privacidad
                </a>
                <a href="#" class="footer-link">
                    <i class="fas fa-envelope"></i> Contacto | piagestiondisciplinaria1@gmail.com
                </a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2025 Institución Educativa Santa Teresa. Todos los derechos reservados.</p>
        </div>
    </footer>

    <!-- Modal de formulario para registros -->
    <div class="form-modal" id="recordModal">
        <div class="form-content">
            <h3 id="modalTitle">Nuevo Registro Disciplinario</h3>
            <form id="recordForm">
                <input type="hidden" id="recordId" name="record_id">
                
                <div class="form-group">
                    <label for="fecha">Fecha del Incidente:</label>
                    <input type="date" id="fecha" name="fecha" required>
                </div>

                <div class="form-group">
                    <label for="estudianteNombre">Nombre del Estudiante:</label>
                    <input type="text" id="estudianteNombre" name="estudiante_nombre" required placeholder="Nombre completo del estudiante">
                </div>

                <div class="form-group">
                    <label for="estudianteGrupo">Grupo:</label>
                    <select id="estudianteGrupo" name="estudiante_grupo" required>
                        <option value="">Seleccionar grupo</option>
                        <option value="0-1">0-1</option>
                        <option value="0-2">0-2</option>
                        <option value="0-3">0-3</option>
                        <option value="0-4">0-4</option>
                        <option value="1-1">1-1</option>
                        <option value="1-2">1-2</option>
                        <option value="1-3">1-3</option>
                        <option value="2-1">2-1</option>
                        <option value="2-2">2-2</option>
                        <option value="2-3">2-3</option>
                        <option value="3-1">3-1</option>
                        <option value="3-2">3-2</option>
                        <option value="3-3">3-3</option>
                        <option value="4-1">4-1</option>
                        <option value="4-2">4-2</option>
                        <option value="4-3">4-3</option>
                        <option value="5-1">5-1</option>
                        <option value="5-2">5-2</option>
                        <option value="5-3">5-3</option>
                        <option value="6-1">6-1</option>
                        <option value="6-2">6-2</option>
                        <option value="6-3">6-3</option>
                        <option value="6-4">6-4</option>
                        <option value="7-1">7-1</option>
                        <option value="7-2">7-2</option>
                        <option value="7-3">7-3</option>
                        <option value="8-1">8-1</option>
                        <option value="8-2">8-2</option>
                        <option value="8-3">8-3</option>
                        <option value="9-1">9-1</option>
                        <option value="9-2">9-2</option>
                        <option value="9-3">9-3</option>
                        <option value="10-1">10-1</option>
                        <option value="10-2">10-2</option>
                        <option value="10-3">10-3</option>
                        <option value="11-1">11-1</option>
                        <option value="11-2">11-2</option>
                        <option value="11-3">11-3</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="descripcionFalta">Descripción de la Falta:</label>
                    <textarea id="descripcionFalta" name="descripcion_falta" rows="4" required placeholder="Describa detalladamente el incidente ocurrido..."></textarea>
                </div>

                <div class="form-group">
                    <label for="tipoFalta">Tipo de Falta:</label>
                    <select id="tipoFalta" name="tipo_falta" required>
                        <option value="">Seleccionar tipo</option>
                        <option value="leve">Leve</option>
                        <option value="grave">Grave</option>
                        <option value="muy_grave">Muy Grave</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="sancionAplicada">Sanción Aplicada:</label>
                    <textarea id="sancionAplicada" name="sancion_aplicada" rows="3" placeholder="Describa la sanción o medida correctiva aplicada..."></textarea>
                </div>

                <div class="form-group">
                    <label for="observaciones">Observaciones:</label>
                    <textarea id="observaciones" name="observaciones" rows="3" placeholder="Observaciones adicionales..."></textarea>
                </div>

                <div class="form-group">
                    <label for="docenteNombre">Nombre del Docente:</label>
                    <input type="text" id="docenteNombre" name="docente_nombre" required placeholder="Nombre completo del docente que reporta">
                </div>

                <div style="display: flex; gap: 15px; justify-content: center; margin-top: 30px;">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Guardar
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="closeRecordModal()">
                        <i class="fas fa-times"></i> Cancelar
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal de firma digital -->
    <div class="signature-modal" id="signatureModal">
        <div class="signature-content">
            <h4 id="signatureTitle">Firma Digital</h4>
            <p id="signatureSubtitle">Por favor, dibuje su firma en el área de abajo:</p>
            
            <canvas id="signatureCanvas" class="signature-canvas" width="500" height="200"></canvas>
            
            <div class="signature-buttons">
                <button type="button" class="btn btn-secondary" onclick="clearSignature()">
                    <i class="fas fa-eraser"></i> Limpiar
                </button>
                <button type="button" class="btn btn-success" onclick="saveSignature()">
                    <i class="fas fa-check"></i> Guardar Firma
                </button>
                <button type="button" class="btn btn-danger" onclick="closeSignatureModal()">
                    <i class="fas fa-times"></i> Cancelar
                </button>
            </div>
        </div>
    </div>

    <!-- Toast notifications -->
    <div class="toast-container" id="toastContainer"></div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>
   // Variables globales
let currentRecordId = null;
let currentSignatureType = null;
let isDrawing = false;
let canvas, ctx;

// Inicialización
document.addEventListener('DOMContentLoaded', function() {
    initializeSlider();
    initializeCanvas();
    loadRecords();
    setupEventListeners();
});

// Slider de fondo
function initializeSlider() {
    const slides = document.querySelectorAll('.slide');
    let currentSlide = 0;
    
    function showSlide(index) {
        slides.forEach((slide, i) => slide.classList.toggle('active', i === index));
    }

    function nextSlide() {
        currentSlide = (currentSlide + 1) % slides.length;
        showSlide(currentSlide);
    }

    showSlide(0);
    setInterval(nextSlide, 5000);
}

// Inicializar canvas para firmas
function initializeCanvas() {
    canvas = document.getElementById('signatureCanvas');
    ctx = canvas.getContext('2d');
    
    // Configurar canvas
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // Eventos de mouse
    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseout', stopDrawing);

    // Eventos táctiles
    canvas.addEventListener('touchstart', handleTouch);
    canvas.addEventListener('touchmove', handleTouch);
    canvas.addEventListener('touchend', stopDrawing);
}

// Event listeners
function setupEventListeners() {
    // Búsqueda y filtros
    document.getElementById('searchInput').addEventListener('input', debounce(loadRecords, 500));
    document.getElementById('groupFilter').addEventListener('change', loadRecords);
    document.getElementById('startDate').addEventListener('change', loadRecords);
    document.getElementById('endDate').addEventListener('change', loadRecords);

    // Formulario de registro
    document.getElementById('recordForm').addEventListener('submit', handleRecordSubmit);
}

// Funciones de dibujo en canvas
function startDrawing(e) {
    isDrawing = true;
    const rect = canvas.getBoundingClientRect();
    ctx.beginPath();
    ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
}

function draw(e) {
    if (!isDrawing) return;
    const rect = canvas.getBoundingClientRect();
    ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
    ctx.stroke();
}

function stopDrawing() {
    isDrawing = false;
}

function handleTouch(e) {
    e.preventDefault();
    const touch = e.touches[0];
    const rect = canvas.getBoundingClientRect();
    const mouseEvent = new MouseEvent(e.type === 'touchstart' ? 'mousedown' : 
                                     e.type === 'touchmove' ? 'mousemove' : 'mouseup', {
        clientX: touch.clientX,
        clientY: touch.clientY
    });
    canvas.dispatchEvent(mouseEvent);
}

function clearSignature() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}

// Cargar registros
async function loadRecords() {
    showLoading(true);
    
    const params = new URLSearchParams({
        action: 'get_records',
        search: document.getElementById('searchInput').value,
        grupo: document.getElementById('groupFilter').value,
        fecha_inicio: document.getElementById('startDate').value,
        fecha_fin: document.getElementById('endDate').value
    });

    try {
        const response = await fetch(`signature_handler.php?${params}`);
        const data = await response.json();
        
        if (data.success) {
            renderRecords(data.records);
        } else {
            showToast('Error al cargar registros: ' + (data.error || 'Error desconocido'), 'error');
        }
    } catch (error) {
        console.error('Error de conexión:', error);
        showToast('Error de conexión: ' + error.message, 'error');
    } finally {
        showLoading(false);
    }
}

// Renderizar registros en la tabla
function renderRecords(records) {
    const tbody = document.getElementById('recordsTableBody');
    
    if (records.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="text-center">No se encontraron registros</td></tr>';
    } else {
        tbody.innerHTML = records.map(record => `
            <tr>
                <td>${formatDate(record.fecha_registro)}</td>
                <td>${escapeHtml(record.estudiante_nombre)}</td>
                <td>${escapeHtml(record.estudiante_grupo)}</td>
                <td>${escapeHtml(record.descripcion_falta)}</td>
                <td><span class="badge bg-${getBadgeClass(record.tipo_falta)}">${record.tipo_falta}</span></td>
                <td>${escapeHtml(record.sancion_aplicada || '')}</td>
                <td>${escapeHtml(record.docente_nombre)}</td>
                <td>
                    <div class="signature-cell">
                        ${record.firma_estudiante == '1' && record.firma_estudiante_base64 ? `
                            <img src="${record.firma_estudiante_base64}" alt="Firma estudiante" class="signature-image" onclick="viewSignature('${record.firma_estudiante_base64}', 'Firma del Estudiante')">
                            <button class="signature-btn signed" 
                                    onclick="openSignatureModal(${record.id}, 'estudiante')" 
                                    title="Editar firma">
                                <i class="fas fa-edit"></i> Editar
                            </button>
                        ` : `
                            <button class="signature-btn unsigned" 
                                    onclick="openSignatureModal(${record.id}, 'estudiante')" 
                                    title="Agregar firma">
                                <i class="fas fa-pen"></i> Firmar
                            </button>
                        `}
                    </div>
                </td>
                <td>
                    <div class="signature-cell">
                        ${record.firma_docente == '1' && record.firma_docente_base64 ? `
                            <img src="${record.firma_docente_base64}" alt="Firma docente" class="signature-image" onclick="viewSignature('${record.firma_docente_base64}', 'Firma del Docente')">
                            <button class="signature-btn signed" 
                                    onclick="openSignatureModal(${record.id}, 'docente')" 
                                    title="Editar firma">
                                <i class="fas fa-edit"></i> Editar
                            </button>
                        ` : `
                            <button class="signature-btn unsigned" 
                                    onclick="openSignatureModal(${record.id}, 'docente')" 
                                    title="Agregar firma">
                                <i class="fas fa-pen"></i> Firmar
                            </button>
                        `}
                    </div>
                </td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="editRecord(${record.id})" title="Editar">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteRecord(${record.id})" title="Eliminar">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    }
}

// Abrir modal de registro
function openRecordModal(recordId = null) {
    currentRecordId = recordId;
    document.getElementById('modalTitle').textContent = recordId ? 'Editar Registro' : 'Nuevo Registro';
    
    if (recordId) {
        // Cargar datos del registro para edición
        loadRecordData(recordId);
    } else {
        document.getElementById('recordForm').reset();
        document.getElementById('recordId').value = '';
        document.getElementById('fecha').value = new Date().toISOString().split('T')[0];
    }
    
    document.getElementById('recordModal').classList.add('show');
}

function closeRecordModal() {
    document.getElementById('recordModal').classList.remove('show');
    document.getElementById('recordForm').reset();
    currentRecordId = null;
}

// Cargar datos de un registro específico
async function loadRecordData(recordId) {
    try {
        const response = await fetch(`signature_handler.php?action=get_record_data&record_id=${recordId}`);
        const data = await response.json();
        
        if (data.success) {
            const record = data.record;
            document.getElementById('recordId').value = record.id;
            document.getElementById('fecha').value = record.fecha_registro;
            document.getElementById('estudianteNombre').value = record.estudiante_nombre;
            document.getElementById('estudianteGrupo').value = record.estudiante_grupo;
            document.getElementById('descripcionFalta').value = record.descripcion_falta;
            document.getElementById('tipoFalta').value = record.tipo_falta;
            document.getElementById('sancionAplicada').value = record.sancion_aplicada || '';
            document.getElementById('observaciones').value = record.observaciones || '';
            document.getElementById('docenteNombre').value = record.docente_nombre;
        } else {
            showToast('Error al cargar datos del registro: ' + data.error, 'error');
        }
    } catch (error) {
        showToast('Error de conexión: ' + error.message, 'error');
    }
}

// Manejar envío del formulario
async function handleRecordSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    formData.append('action', 'save_record');
    
    try {
        const response = await fetch('signature_handler.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast(data.message || 'Registro guardado exitosamente', 'success');
            closeRecordModal();
            loadRecords();
        } else {
            showToast('Error al guardar: ' + (data.error || 'Error desconocido'), 'error');
        }
    } catch (error) {
        console.error('Error al enviar formulario:', error);
        showToast('Error de conexión: ' + error.message, 'error');
    }
}

// Abrir modal de firma
function openSignatureModal(recordId, signatureType) {
    currentRecordId = recordId;
    currentSignatureType = signatureType;
    
    document.getElementById('signatureTitle').textContent = `Firma ${signatureType === 'estudiante' ? 'del Estudiante' : 'del Docente'}`;
    document.getElementById('signatureSubtitle').textContent = 
        `Por favor, ${signatureType === 'estudiante' ? 'que el estudiante dibuje' : 'dibuje'} su firma en el área de abajo:`;
    
    clearSignature();
    document.getElementById('signatureModal').classList.add('show');
    
    // Ajustar tamaño del canvas si es necesario
    setTimeout(() => {
        const rect = canvas.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
            canvas.width = Math.min(500, rect.width - 4);
            canvas.height = 200;
            // Reconfigurar contexto después del resize
            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 2;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
        }
    }, 100);
}

function closeSignatureModal() {
    document.getElementById('signatureModal').classList.remove('show');
    currentRecordId = null;
    currentSignatureType = null;
}

// Verificar si el canvas tiene contenido
function isCanvasEmpty() {
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    
    // Verificar si hay píxeles no transparentes
    for (let i = 0; i < data.length; i += 4) {
        if (data[i + 3] !== 0) { // Canal alpha
            return false;
        }
    }
    return true;
}

// Guardar firma
async function saveSignature() {
    if (!currentRecordId || !currentSignatureType) {
        showToast('Error: Información de firma incompleta', 'error');
        return;
    }

    // Verificar que hay algo dibujado
    if (isCanvasEmpty()) {
        showToast('Por favor, dibuje una firma antes de guardar', 'error');
        return;
    }

    const imageData = canvas.toDataURL('image/png');
    
    const formData = new FormData();
    formData.append('action', 'save_signature');
    formData.append('record_id', currentRecordId);
    formData.append('tipo_firma', currentSignatureType);
    formData.append('firma_data', imageData);

    try {
        const response = await fetch('signature_handler.php', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (data.success) {
            showToast(data.message || 'Firma guardada exitosamente', 'success');
            closeSignatureModal();
            loadRecords();
        } else {
            showToast('Error al guardar firma: ' + (data.error || 'Error desconocido'), 'error');
        }
    } catch (error) {
        console.error('Error al guardar firma:', error);
        showToast('Error de conexión: ' + error.message, 'error');
    }
}

// Editar registro
async function editRecord(recordId) {
    openRecordModal(recordId);
}

// Eliminar registro
async function deleteRecord(recordId) {
    if (!confirm('¿Está seguro de que desea eliminar este registro?')) return;

    const formData = new FormData();
    formData.append('action', 'delete_record');
    formData.append('record_id', recordId);

    try {
        const response = await fetch('signature_handler.php', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (data.success) {
            showToast(data.message || 'Registro eliminado exitosamente', 'success');
            loadRecords();
        } else {
            showToast('Error al eliminar: ' + (data.error || 'Error desconocido'), 'error');
        }
    } catch (error) {
        console.error('Error al eliminar:', error);
        showToast('Error de conexión: ' + error.message, 'error');
    }
}

// Función para visualizar firma en modal
function viewSignature(base64Image, title) {
    // Crear modal dinámicamente si no existe
    let modal = document.getElementById('signatureViewModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'signatureViewModal';
        modal.className = 'signature-view-modal';
        modal.innerHTML = `
            <div class="signature-view-content">
                <h4 id="signatureViewTitle">Visualizar Firma</h4>
                <img id="signatureViewImage" class="signature-view-image" alt="Firma">
                <div style="margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeSignatureViewModal()">
                        <i class="fas fa-times"></i> Cerrar
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }
    
    // Configurar contenido del modal
    document.getElementById('signatureViewTitle').textContent = title;
    document.getElementById('signatureViewImage').src = base64Image;
    modal.classList.add('show');
}

function closeSignatureViewModal() {
    const modal = document.getElementById('signatureViewModal');
    if (modal) {
        modal.classList.remove('show');
    }
}

// Funciones auxiliares
function showLoading(show) {
    document.getElementById('loading').style.display = show ? 'block' : 'none';
    document.getElementById('recordsTable').style.display = show ? 'none' : 'table';
}

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast-notification ${type}`;
    toast.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        ${message}
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => toast.classList.add('show'), 100);
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            if (container.contains(toast)) {
                container.removeChild(toast);
            }
        }, 300);
    }, 4000);
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('es-ES');
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function getBadgeClass(tipo) {
    switch(tipo) {
        case 'leve': return 'success';
        case 'grave': return 'warning';
        case 'muy_grave': return 'danger';
        default: return 'secondary';
    }
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Cerrar modales al hacer clic fuera
window.addEventListener('click', function(e) {
    if (e.target.classList.contains('form-modal')) {
        closeRecordModal();
    }
    if (e.target.classList.contains('signature-modal')) {
        closeSignatureModal();
    }
    if (e.target.classList.contains('signature-view-modal')) {
        closeSignatureViewModal();
    }
});


// Función para visualizar firma en modal
function viewSignature(base64Image, title) {
    // Crear modal dinámicamente si no existe
    let modal = document.getElementById('signatureViewModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'signatureViewModal';
        modal.className = 'signature-view-modal';
        modal.innerHTML = `
            <div class="signature-view-content">
                <h4 id="signatureViewTitle">Visualizar Firma</h4>
                <img id="signatureViewImage" class="signature-view-image" alt="Firma">
                <div style="margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeSignatureViewModal()">
                        <i class="fas fa-times"></i> Cerrar
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }
    
    // Configurar contenido del modal
    document.getElementById('signatureViewTitle').textContent = title;
    document.getElementById('signatureViewImage').src = base64Image;
    modal.classList.add('show');
}

function closeSignatureViewModal() {
    const modal = document.getElementById('signatureViewModal');
    if (modal) {
        modal.classList.remove('show');
    }
}

// Cerrar modal de visualización al hacer clic fuera
window.addEventListener('click', function(e) {
    if (e.target.classList.contains('form-modal')) {
        closeRecordModal();
    }
    if (e.target.classList.contains('signature-modal')) {
        closeSignatureModal();
    }
    if (e.target.classList.contains('signature-view-modal')) {
        closeSignatureViewModal();
    }
});
    </script>
</body>
</html>
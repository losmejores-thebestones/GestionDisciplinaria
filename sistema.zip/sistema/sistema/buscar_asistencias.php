<?php
include 'conexion.php';


// Construcción segura de condiciones
$condiciones = [];

// Filtrar por nombre
if (!empty($_GET['buscar'])) {
  $buscar = $conn->real_escape_string($_GET['buscar']);
  $condiciones[] = "(nombre LIKE '%$buscar%' OR grupo LIKE '%$buscar%')";
}


// Filtrar por grupo
if (!empty($_GET['grupo'])) {
  $grupo = $conn->real_escape_string($_GET['grupo']);
$condiciones[] = "grupo = '$grupo'";
}

// Armar cláusula WHERE si hay condiciones
$where = count($condiciones) > 0 ? 'WHERE ' . implode(' AND ', $condiciones) : '';

// Consulta SQL final
$sql = "
  SELECT nombre, grupo, enero, febrero, marzo, abril, mayo, junio, julio, agosto, septiembre, octubre, noviembre
  FROM asistencias
  $where
";

$result = $conn->query($sql);
$meses = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre'];

if ($result && $result->num_rows > 0):
  while ($row = $result->fetch_assoc()):
?>
  <tr>
    <td><?= htmlspecialchars($row['nombre']) ?></td>
    <td>
      <button class="guardar-cambios boton-guardar" data-nombre="<?= htmlspecialchars($row['nombre']) ?>">
        <i class="fas fa-save"></i> Guardar
      </button>
    </td>
    <td><?= htmlspecialchars($row['grupo']) ?></td>

    <?php foreach ($meses as $mes):
      $xArray = array_filter(explode(',', $row[$mes])); ?>
      <td>
        <div class="mes" data-mes="<?= $mes ?>" style="display: grid;">
          <?php
  // Mostrar al menos 10 mini-celdas por mes, marcadas o vacías
  $cantidad = max(10, count($xArray)); 
  for ($i = 0; $i < $cantidad; $i++):
    $valor = isset($xArray[$i]) && trim($xArray[$i]) === 'X' ? 'X' : '';
    $clase = $valor === 'X' ? 'mini-celda x' : 'mini-celda';
?>
  <div class="<?= $clase ?>"><?= $valor ?></div>
<?php endfor; ?>

        </div>
      </td>
    <?php endforeach; ?>
  </tr>
<?php
  endwhile;
else:
?>
  <tr>
    <td colspan="15" style="text-align: center; padding: 1rem; color: gray;">
      No se encontraron resultados.
    </td>
  </tr>
<?php endif; ?>

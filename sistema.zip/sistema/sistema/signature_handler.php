<?php
session_start();

// Configuración de errores para depuración
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Headers para JSON
header('Content-Type: application/json');

// Verificar sesión
if (!isset($_SESSION['usuario'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit();
}

// Configuración de base de datos
$host = 'localhost';
$dbname = 'sistema_disciplinario';
$username = 'root'; // Cambiar según tu configuración
$password = ''; // Cambiar según tu configuración

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Error de conexión: ' . $e->getMessage()]);
    exit();
}

// Crear columnas de firma en la tabla principal si no existen
try {
    $pdo->exec("ALTER TABLE registro_disciplinario 
                ADD COLUMN IF NOT EXISTS firma_estudiante_data LONGBLOB NULL,
                ADD COLUMN IF NOT EXISTS firma_docente_data LONGBLOB NULL");
} catch(PDOException $e) {
    // Ignorar error si las columnas ya existen
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch($action) {
    case 'save_record':
        saveRecord($pdo);
        break;
    case 'save_signature':
        saveSignature($pdo);
        break;
    case 'get_records':
        getRecords($pdo);
        break;
    case 'delete_record':
        deleteRecord($pdo);
        break;
    case 'get_signature':
        getSignature($pdo);
        break;
    case 'get_record_data':
        getRecordData($pdo);
        break;
    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Acción no válida']);
}

function saveRecord($pdo) {
    try {
        $fecha = $_POST['fecha'] ?? '';
        $estudiante_nombre = $_POST['estudiante_nombre'] ?? '';
        $estudiante_grupo = $_POST['estudiante_grupo'] ?? '';
        $descripcion_falta = $_POST['descripcion_falta'] ?? '';
        $tipo_falta = $_POST['tipo_falta'] ?? '';
        $sancion_aplicada = $_POST['sancion_aplicada'] ?? '';
        $observaciones = $_POST['observaciones'] ?? '';
        $docente_nombre = $_POST['docente_nombre'] ?? '';
        $record_id = $_POST['record_id'] ?? null;

        // Validaciones básicas
        if (empty($fecha) || empty($estudiante_nombre) || empty($estudiante_grupo) || 
            empty($descripcion_falta) || empty($tipo_falta) || empty($docente_nombre)) {
            echo json_encode(['success' => false, 'error' => 'Todos los campos obligatorios deben ser completados']);
            return;
        }

        if ($record_id && !empty($record_id)) {
            // Actualizar registro existente
            $stmt = $pdo->prepare("UPDATE registro_disciplinario SET 
                fecha_registro = ?, estudiante_nombre = ?, estudiante_grupo = ?, 
                descripcion_falta = ?, tipo_falta = ?, sancion_aplicada = ?, 
                observaciones = ?, docente_nombre = ? WHERE id = ?");
            $stmt->execute([$fecha, $estudiante_nombre, $estudiante_grupo, 
                          $descripcion_falta, $tipo_falta, $sancion_aplicada, 
                          $observaciones, $docente_nombre, $record_id]);
            echo json_encode(['success' => true, 'record_id' => $record_id, 'message' => 'Registro actualizado exitosamente']);
        } else {
            // Crear nuevo registro
            $stmt = $pdo->prepare("INSERT INTO registro_disciplinario 
                (fecha_registro, estudiante_nombre, estudiante_grupo, descripcion_falta, 
                 tipo_falta, sancion_aplicada, observaciones, docente_nombre) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$fecha, $estudiante_nombre, $estudiante_grupo, 
                          $descripcion_falta, $tipo_falta, $sancion_aplicada, 
                          $observaciones, $docente_nombre]);
            $new_id = $pdo->lastInsertId();
            echo json_encode(['success' => true, 'record_id' => $new_id, 'message' => 'Registro creado exitosamente']);
        }
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error al guardar registro: ' . $e->getMessage()]);
    }
}

function saveSignature($pdo) {
    try {
        $record_id = $_POST['record_id'] ?? '';
        $tipo_firma = $_POST['tipo_firma'] ?? '';
        $firma_data = $_POST['firma_data'] ?? '';

        // Validaciones
        if (empty($record_id) || empty($tipo_firma) || empty($firma_data)) {
            echo json_encode(['success' => false, 'error' => 'Datos incompletos para guardar la firma']);
            return;
        }

        if (!in_array($tipo_firma, ['estudiante', 'docente'])) {
            echo json_encode(['success' => false, 'error' => 'Tipo de firma no válido']);
            return;
        }

        // Verificar que el registro existe
        $stmt = $pdo->prepare("SELECT id FROM registro_disciplinario WHERE id = ?");
        $stmt->execute([$record_id]);
        if (!$stmt->fetch()) {
            echo json_encode(['success' => false, 'error' => 'Registro no encontrado']);
            return;
        }

        // Procesar la imagen de la firma
        if (strpos($firma_data, 'data:image/png;base64,') === 0) {
            $firma_data = str_replace('data:image/png;base64,', '', $firma_data);
        }
        
        $firma_binary = base64_decode($firma_data);
        
        if ($firma_binary === false) {
            echo json_encode(['success' => false, 'error' => 'Error al procesar la imagen de la firma']);
            return;
        }

        // Determinar la columna según el tipo de firma
        $column = ($tipo_firma === 'estudiante') ? 'firma_estudiante_data' : 'firma_docente_data';
        
        // Guardar la firma en la columna correspondiente
        $stmt = $pdo->prepare("UPDATE registro_disciplinario SET $column = ? WHERE id = ?");
        $stmt->execute([$firma_binary, $record_id]);

        echo json_encode(['success' => true, 'message' => 'Firma guardada exitosamente']);

    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error al guardar firma: ' . $e->getMessage()]);
    } catch(Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error inesperado: ' . $e->getMessage()]);
    }
}

function getRecords($pdo) {
    try {
        $search = $_GET['search'] ?? '';
        $grupo = $_GET['grupo'] ?? '';
        $fecha_inicio = $_GET['fecha_inicio'] ?? '';
        $fecha_fin = $_GET['fecha_fin'] ?? '';

        $sql = "SELECT r.*, 
                CASE WHEN r.firma_estudiante_data IS NOT NULL THEN 1 ELSE 0 END as firma_estudiante,
                CASE WHEN r.firma_docente_data IS NOT NULL THEN 1 ELSE 0 END as firma_docente
                FROM registro_disciplinario r WHERE 1=1";

        $params = [];

        if ($search) {
            $sql .= " AND (r.estudiante_nombre LIKE ? OR r.descripcion_falta LIKE ? OR r.docente_nombre LIKE ?)";
            $searchParam = "%$search%";
            $params[] = $searchParam;
            $params[] = $searchParam;
            $params[] = $searchParam;
        }

        if ($grupo) {
            $sql .= " AND r.estudiante_grupo = ?";
            $params[] = $grupo;
        }

        if ($fecha_inicio) {
            $sql .= " AND r.fecha_registro >= ?";
            $params[] = $fecha_inicio;
        }

        if ($fecha_fin) {
            $sql .= " AND r.fecha_registro <= ?";
            $params[] = $fecha_fin;
        }

        $sql .= " ORDER BY r.fecha_registro DESC, r.id DESC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $records = $stmt->fetchAll();

        // Convertir las firmas a base64 para su display
        foreach ($records as &$record) {
            if ($record['firma_estudiante_data']) {
                $record['firma_estudiante_base64'] = 'data:image/png;base64,' . base64_encode($record['firma_estudiante_data']);
                unset($record['firma_estudiante_data']); // Remover datos binarios para optimizar
            }
            if ($record['firma_docente_data']) {
                $record['firma_docente_base64'] = 'data:image/png;base64,' . base64_encode($record['firma_docente_data']);
                unset($record['firma_docente_data']); // Remover datos binarios para optimizar
            }
        }

        echo json_encode(['success' => true, 'records' => $records]);
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error al obtener registros: ' . $e->getMessage()]);
    }
}

function getRecordData($pdo) {
    try {
        $record_id = $_GET['record_id'] ?? '';
        
        if (empty($record_id)) {
            echo json_encode(['success' => false, 'error' => 'ID de registro requerido']);
            return;
        }

        $stmt = $pdo->prepare("SELECT * FROM registro_disciplinario WHERE id = ?");
        $stmt->execute([$record_id]);
        $record = $stmt->fetch();

        if ($record) {
            // Remover datos binarios de firma para optimizar la respuesta
            unset($record['firma_estudiante_data']);
            unset($record['firma_docente_data']);
            echo json_encode(['success' => true, 'record' => $record]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Registro no encontrado']);
        }
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error al obtener registro: ' . $e->getMessage()]);
    }
}

function deleteRecord($pdo) {
    try {
        $record_id = $_POST['record_id'] ?? '';

        if (empty($record_id)) {
            echo json_encode(['success' => false, 'error' => 'ID de registro requerido']);
            return;
        }

        // Eliminar el registro (las firmas se eliminan automáticamente al estar en la misma tabla)
        $stmt = $pdo->prepare("DELETE FROM registro_disciplinario WHERE id = ?");
        $stmt->execute([$record_id]);
        
        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Registro eliminado exitosamente']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Registro no encontrado']);
        }
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error al eliminar: ' . $e->getMessage()]);
    }
}

function getSignature($pdo) {
    try {
        $record_id = $_GET['record_id'] ?? '';
        $tipo_firma = $_GET['tipo_firma'] ?? '';

        if (empty($record_id) || empty($tipo_firma)) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Datos incompletos']);
            return;
        }

        $column = ($tipo_firma === 'estudiante') ? 'firma_estudiante_data' : 'firma_docente_data';
        $stmt = $pdo->prepare("SELECT $column FROM registro_disciplinario WHERE id = ?");
        $stmt->execute([$record_id]);
        $result = $stmt->fetch();

        if ($result && $result[$column]) {
            header('Content-Type: image/png');
            echo $result[$column];
        } else {
            header('Content-Type: application/json');
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Firma no encontrada']);
        }
    } catch(PDOException $e) {
        header('Content-Type: application/json');
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error al obtener firma: ' . $e->getMessage()]);
    }
}
?>
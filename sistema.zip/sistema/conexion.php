<?php
$host = "localhost";
$db = "sistema_disciplinario";
$user = "root"; // Cambia si tu usuario de MySQL es distinto
$pass = "";     // Cambia si tienes una contraseña

// Crear conexión
$conn = new mysqli($host, $user, $pass, $db);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>


